﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bluekey.CallCenter.DataAcces;

namespace Bluekey.CallCenter.BusinessRule
{
    public class BOS_Orden
    {
        private string _errorMessage;
        private string _errorSource;

        public long Corporativo { get; set; }
        public string Central { get; set; }
        public long Orden { get; set; }
        public string Sucursal { get; set; }
        public long Id_Cliente { get; set; }
        public int Id_Direccion { get; set; }
        public int Comensales { get; set; }
        public int Turno { get; set; }
        public string Nota { get; set; }
        public string Origen { get; set; }
        public string Forma_Pago { get; set; }
        public string Fecha_Captura_Inicio { get; set; }
        public string Operador_Captura { get; set; }
        public string Fecha_Captura_Fin { get; set; }
        public string Fecha_Procesar { get; set; }
        public string Promesa_Entrega { get; set; }
        public string Estatus { get; set; }
        public long Repartidor { get; set; }
        public string Usuario_Cancela { get; set; }
        public string Fecha_Cancela { get; set; }
        public string Nota_Cancela { get; set; }
        public string RFC { get; set; }
        public string Codigo_Postal { get; set; }

        List<BOS_Orden> listaOrden = new List<BOS_Orden>();

        public int insertaOrden()
        {
            int returnValue = 0;

            try
            {
                DataAccess dao = new DataAccess();

                SqlParameter[] parameters = new SqlParameter[22];
                parameters[0] = new SqlParameter("@Corporativo", this.Corporativo);
                parameters[1] = new SqlParameter("@Central", this.Central);
                parameters[2] = new SqlParameter("@Sucursal", this.Sucursal);
                parameters[3] = new SqlParameter("@IdCliente", this.Id_Cliente);
                parameters[4] = new SqlParameter("@IdDireccion", this.Id_Direccion);
                parameters[5] = new SqlParameter("@Comensales", this.Comensales);
                parameters[6] = new SqlParameter("@Turno", this.Turno);
                parameters[7] = new SqlParameter("@Nota", this.Nota);
                parameters[8] = new SqlParameter("@Origen", this.Origen);
                parameters[9] = new SqlParameter("@FormaPago", this.Forma_Pago);
                parameters[10] = new SqlParameter("@FechaCapturaInicio", this.Fecha_Captura_Inicio);
                parameters[11] = new SqlParameter("@OperadorCaptura", this.Operador_Captura);
                parameters[12] = new SqlParameter("@FechaCapturaFin", this.Fecha_Captura_Fin);
                parameters[13] = new SqlParameter("@FechaProcesar", this.Fecha_Procesar);
                parameters[14] = new SqlParameter("@PromesaEntrega", this.Promesa_Entrega);
                parameters[15] = new SqlParameter("@Estatus", this.Estatus);
                parameters[16] = new SqlParameter("@Repartidor", this.Repartidor);
                parameters[17] = new SqlParameter("@UsuarioCancela", this.Usuario_Cancela);
                parameters[18] = new SqlParameter("@FechaCancela", this.Fecha_Cancela);
                parameters[19] = new SqlParameter("@NotaCancela", this.Nota_Cancela);
                parameters[20] = new SqlParameter("@RFC", this.RFC);
                parameters[21] = new SqlParameter("@CodigoPostal", this.Codigo_Postal);

                SqlParameter paramReturn = new SqlParameter("@Orden", 0);
                paramReturn.Direction = System.Data.ParameterDirection.Output;
                dao.ExecuteNonQuery("bos_spi_ordenes", parameters, paramReturn);
                returnValue = int.Parse(paramReturn.Value.ToString());

            }
            catch (Exception ex)
            {
                _errorMessage = ex.Message;
                _errorSource = ex.Source;
                returnValue = 0;
            }
            return returnValue;
        }
    }
}
