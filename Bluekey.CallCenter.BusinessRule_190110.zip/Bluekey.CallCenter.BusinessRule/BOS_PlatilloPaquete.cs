﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bluekey.CallCenter.BusinessRule
{
    public class BOS_PlatilloPaquete
    {
       
        public long Corporativo { get; set; }
       
        public string Central { get; set; }
     
        public long Paquete { get; set; }
       
        public long Platillo { get; set; }

        public int Cantidad { get; set; }

        #region public methods

        #endregion


    }
}
