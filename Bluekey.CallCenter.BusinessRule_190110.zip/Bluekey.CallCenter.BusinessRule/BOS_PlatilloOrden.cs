﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bluekey.CallCenter.BusinessRule
{
    public class BOS_PlatilloOrden
    {
    
       public int Id { get; set; }

        public int Platillo { get; set; }

        public int Linea_Paquete { get; set; }     

        public int Grupo { get; set; }

        public string Clasificacion { get; set; }

        public bool Modificador { get; set; }

        public int Modificador_Cantidad { get; set; }

        public bool Terminador { get; set; }
        
        public decimal Precio { get; set; }
        
        public bool Paquete { get; set; }

        public bool Promocion { get; set; }

        public int Equivalencia { get; set; }

        public bool Procesado { get; set; }

        public bool NoPregunta { get; set; }

    }
}
