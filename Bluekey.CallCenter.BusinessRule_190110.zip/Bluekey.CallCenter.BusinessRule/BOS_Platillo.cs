﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bluekey.CallCenter.DataAcces;

namespace Bluekey.CallCenter.BusinessRule
{
    public class BOS_Platillo
    {
        private string _errorMessage;
        private string _errorSource;

        public long Corporativo { get; set; }
        
        public string Central { get; set; }
      
        public long Platillo { get; set; }
        
        public string Nombre_Platillo { get; set; }

        public long Grupo { get; set; }
       
        public string Clasificacion { get; set; }

        public double Servicio { get; set; }

        public long Comandera { get; set; }

        public bool Modificador { get; set; }
       
        public int Modificador_Cantidad { get; set; }

        public bool Terminador { get; set; }

        public int Tiempo { get; set; }
       
        public decimal Precio { get; set; }
        
        public bool Desglosa_Servicio { get; set; }

        public bool Paquete { get; set; }

        public bool Promocion { get; set; }
                
        public string Color { get; set; }

        public bool Activo { get; set; }

        public int Turno { get; set; }

        public string FechaProceso { get; set; }

        #region public methods


        //Consulta platillos por Corporativo y central
        // por Grupo o Platillo 
        public DataTable mgetConsultaPlatillosGrupo()
        {

            DataAccess dao = new DataAccess();
            DataSet dset = new DataSet();
            DataTable dtable = new DataTable();

            try
            {
                SqlParameter[] parameters = new SqlParameter[4];
                parameters[0] = new SqlParameter("@Corporativo", this.Corporativo);
                parameters[1] = new SqlParameter("@Central", this.Central);
                parameters[2] = new SqlParameter("@Grupo", this.Grupo);
                parameters[3] = new SqlParameter("@Platillo", this.Platillo);

                dset = dao.ExecuteDataSet("bos_sp_platillos", parameters);
                if (dset.Tables.Count > 0)
                    dtable = dset.Tables[0];

            }
            catch (Exception ex)
            {
                _errorMessage = ex.Message;
                _errorSource = ex.Source;
                throw;

            }
            return dtable;
        }

        public DataTable mgetConsultaPlatillosNombre()
        {

            DataAccess dao = new DataAccess();
            DataSet dset = new DataSet();
            DataTable dtable = new DataTable();

            try
            {
                SqlParameter[] parameters = new SqlParameter[5];
                parameters[0] = new SqlParameter("@Corporativo", this.Corporativo);
                parameters[1] = new SqlParameter("@Central", this.Central);
                parameters[2] = new SqlParameter("@Turno", this.Turno);
                parameters[3] = new SqlParameter("@NombrePlatillo", this.Nombre_Platillo);
                parameters[4] = new SqlParameter("@Fecha", this.FechaProceso);

                dset = dao.ExecuteDataSet("bos_sp_platillosnombre", parameters);
                if (dset.Tables.Count > 0)
                    dtable = dset.Tables[0];

            }
            catch (Exception ex)
            {
                _errorMessage = ex.Message;
                _errorSource = ex.Source;
                throw;

            }
            return dtable;
        }

        #endregion


    }
}
