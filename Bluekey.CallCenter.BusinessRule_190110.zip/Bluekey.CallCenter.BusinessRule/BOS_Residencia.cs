﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bluekey.CallCenter.DataAcces;

namespace Bluekey.CallCenter.BusinessRule
{
    public class BOS_Residencia
    {

        private string _errorMessage;
        private string _errorSource;

        public long Corporativo { get; set; }


        public string Residencia { get; set; }

        public string NombreResidencia { get; set; }

        #region public methods
        public DataTable mgetConsultaResidencia()
        {
            DataAccess dao = new DataAccess();
            DataSet dset = new DataSet();
            DataTable dtable = new DataTable();

            try
            {
                SqlParameter[] parameters = new SqlParameter[1];
                parameters[0] = new SqlParameter("@Corporativo", this.Corporativo);              
                dset = dao.ExecuteDataSet("bos_sp_residencia", parameters);
                if (dset.Tables.Count > 0)
                    dtable = dset.Tables[0];

            }
            catch (Exception ex)
            {
                _errorMessage = ex.Message;
                _errorSource = ex.Source;
                throw;

            }
            return dtable;


        }

        #endregion

    }
}
