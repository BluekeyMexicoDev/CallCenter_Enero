﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bluekey.CallCenter.DataAcces;

namespace Bluekey.CallCenter.BusinessRule
{
    public class BOS_Corporativo
    {
        
        public long Corporativo { get; set; }
                
        public string Nombre_Corporativo { get; set; }

        #region public methods

        public DataTable mgetConsultaCorporativo()
        {
            DataAccess dao = new DataAccess();
            DataSet dset = new DataSet();
            DataTable dtable = new DataTable();

            try
            {
                SqlParameter[] parameters = new SqlParameter[1];
                parameters[0] = new SqlParameter("@Corporativo", this.Corporativo);                
                dset = dao.ExecuteDataSet("bos_sp_corporativo", parameters);
                if (dset.Tables.Count > 0)
                    dtable = dset.Tables[0];

            }
            catch
            {

            }
            return dtable;


        }

        #endregion
    }
}
