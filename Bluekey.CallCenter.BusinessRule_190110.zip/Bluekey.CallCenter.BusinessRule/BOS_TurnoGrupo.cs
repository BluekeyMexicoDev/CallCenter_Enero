﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bluekey.CallCenter.DataAcces;

namespace Bluekey.CallCenter.BusinessRule
{
    public class BOS_TurnoGrupo
    {
        
        private string _errorMessage;
        private string _errorSource; 

        public long Corporativo { get; set; }
       
        public string Central { get; set; }
        
        public int Turno { get; set; }
        
        public int Orden { get; set; }
        
        public long Grupo { get; set; }

        public string FechaProceso { get; set; }

        #region public methods

        public DataTable mgetConsultaTurnosGrupos()
        {

            DataAccess dao = new DataAccess();
            DataSet dset = new DataSet();
            DataTable dtable = new DataTable();

            try
            {
                SqlParameter[] parameters = new SqlParameter[4];
                parameters[0] = new SqlParameter("@Corporativo", this.Corporativo);
                parameters[1] = new SqlParameter("@Central", this.Central);
                parameters[2] = new SqlParameter("@Turno", this.Turno);
                parameters[3] = new SqlParameter("@Fecha", this.FechaProceso);
                dset = dao.ExecuteDataSet("bos_sp_turnosgrupos", parameters);
                if (dset.Tables.Count > 0)
                    dtable = dset.Tables[0];

            }
            catch (Exception ex)
            {
                _errorMessage = ex.Message;
                _errorSource = ex.Source;
                throw;

            }
            return dtable;
        }


        #endregion



    }
}
