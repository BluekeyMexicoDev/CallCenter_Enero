﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bluekey.CallCenter.DataAcces;

namespace Bluekey.CallCenter.BusinessRule
{
    public class BOS_Turno
    {
        private string _errorMessage;
        private string _errorSource;
        
        public long Corporativo { get; set; }
        
        public string Central { get; set; }
        
        public int Turno { get; set; }
        
        public string Nombre_Turno { get; set; }
        
        public DateTime? Hora_Inicio { get; set; }
      
        public DateTime? Hora_Fin { get; set; }

        public string HoraTurno { get; set; }

        
        #region public methods

        public DataTable mgetConsultaTurnos()
        {

            DataAccess dao = new DataAccess();
            DataSet dset = new DataSet();
            DataTable dtable = new DataTable();

            try
            {
                SqlParameter[] parameters = new SqlParameter[3];
                parameters[0] = new SqlParameter("@Corporativo", this.Corporativo);
                parameters[1] = new SqlParameter("@Central", this.Central);
                parameters[2] = new SqlParameter("@Turno", this.Turno);
                dset = dao.ExecuteDataSet("bos_sp_turnos", parameters);
                if (dset.Tables.Count > 0)
                    dtable = dset.Tables[0];

            }
            catch (Exception ex)
            {
                _errorMessage = ex.Message;
                _errorSource = ex.Source;
                throw;

            }
            return dtable;
        }


        public DataTable mgetObtieneTurno()
        {
            
            DataAccess dao = new DataAccess();
            DataSet dset = new DataSet();
            DataTable dtable = new DataTable();

            try
            {
                SqlParameter[] parameters = new SqlParameter[3];
                parameters[0] = new SqlParameter("@Corporativo", this.Corporativo);
                parameters[1] = new SqlParameter("@Central", this.Central);
                parameters[2] = new SqlParameter("@Hora", this.HoraTurno);
                dset = dao.ExecuteDataSet("bos_sp_obtieneturno", parameters);
                if (dset.Tables.Count > 0)
                    dtable = dset.Tables[0];

            }
            catch (Exception ex)
            {
                _errorMessage = ex.Message;
                _errorSource = ex.Source;
                throw;

            }
            return dtable;
        }

        #endregion
    }
}
