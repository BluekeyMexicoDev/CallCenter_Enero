﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bluekey.CallCenter.DataAcces;

namespace Bluekey.CallCenter.BusinessRule
{
    public class BOS_Reemplaza
    {
        private string _errorMessage;
        private string _errorSource;

        public int Platillo { get; set; }

        public int PlatilloPromocion { get; set; }

        public string NombrePlatillo { get; set; }

        public int Cantidad { get; set; }

        public decimal Importe { get; set; }     

        public bool Reemplaza { get; set; }

        public bool NoPregunta { get; set; }      

        public string Clasificacion { get; set; }

        public bool Proceso { get; set; }

        public int Linea_Paquete { get; set; }

    }
}
