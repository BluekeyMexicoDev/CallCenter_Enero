﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Bluekey.CallCenter.BusinessRule;


namespace BlueKey.CallCenter.WebApp
{
    public partial class DatosFiscales : System.Web.UI.Page
    {
        int pCorpo;
        string pCentral;
        string pOrigen;
        string pOperador;
        string pTelefono;
        string pSucursal;
        int pIdCliente;
        int pIdDireccion;
        string pRFC;
        DateTime pHoraInicio;    

        private string frmCorpo;
        protected string _frmCorpo { get { return frmCorpo; } }

        private string frmCentral;
        protected string _frmCentral { get { return frmCentral; } }

        private string frmTelefono;
        protected string _frmTelefono { get { return frmTelefono; } }

        private string frmOperador;
        protected string _frmOperador { get { return frmOperador; } }

        private string frmCliente;
        protected string _frmCliente { get { return frmCliente; } }

        private string frmHoraIni;
        protected string _frmHoraIni { get { return frmHoraIni; } }


        //lista de orden
        public List<BOS_Orden> listaOrden
        {
            get
            {
                if (HttpContext.Current.Session["listaOrden"] == null)
                {
                    HttpContext.Current.Session["listaOrden"] = new List<BOS_Orden>();
                }
                return HttpContext.Current.Session["listaOrden"] as List<BOS_Orden>;
            }
            set
            {
                HttpContext.Current.Session["listaOrden"] = value;
            }

        }

        //lista de platillos orden
        public List<BOS_OrdenDetalle> listaOrdenDetalle
        {
            get
            {
                if (HttpContext.Current.Session["listaOrdenDetalle"] == null)
                {
                    HttpContext.Current.Session["listaOrdenDetalle"] = new List<BOS_OrdenDetalle>();
                }
                return HttpContext.Current.Session["listaOrdenDetalle"] as List<BOS_OrdenDetalle>;
            }
            set
            {
                HttpContext.Current.Session["listaOrdenDetalle"] = value;
            }

        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                getLoadQS();
                getDatosFiscales();
                populateMenu();
                //populateGenerales();
                
            }
            else
            {

                pCorpo = int.Parse(HttpContext.Current.Session["sCorpo"].ToString());
                pCentral = HttpContext.Current.Session["sCentral"].ToString();
                pOrigen = HttpContext.Current.Session["sOrigen"].ToString();
                pOperador = HttpContext.Current.Session["sOperador"].ToString();
                pTelefono = HttpContext.Current.Session["sTelefono"].ToString();
                pSucursal = HttpContext.Current.Session["sSucursal"].ToString();
                pIdCliente = int.Parse(HttpContext.Current.Session["sIdCli"].ToString());
                pIdDireccion = int.Parse(HttpContext.Current.Session["sIdDir"].ToString());
                pHoraInicio = DateTime.Parse(HttpContext.Current.Session["sHoraInicio"].ToString());

            }
        }

        private void getLoadQS()
        {
            pCorpo = int.Parse(Request.QueryString["Corpo"].ToString());
            pCentral = Request.QueryString["Central"];
            pOrigen = Request.QueryString["Ori"];
            pOperador = Request.QueryString["Oper"];
            pTelefono = Request.QueryString["Tel"];
            pSucursal = Request.QueryString["Suc"];
            pIdCliente = int.Parse(Request.QueryString["IdCli"].ToString());
            pIdDireccion = int.Parse(Request.QueryString["IdDir"].ToString());
            pHoraInicio = DateTime.Parse(Request.QueryString["HoraI"].ToString());


            Session["sCorpo"] = pCorpo;
            Session["sCentral"] = pCentral;
            Session["sOrigen"] = pOrigen;
            Session["sOperador"] = pOperador;
            Session["sTelefono"] = pTelefono;
            Session["sSucursal"] = pSucursal;
            Session["sIdCli"] = pIdCliente;
            Session["sIdDir"] = pIdDireccion;
            Session["sHoraInicio"] = pHoraInicio; 

        }
        protected string ClientIDPageRedirect()
        {
            return this.paginaredirect.ClientID;
        }

        private void getDatosFiscales()
        {
            this.paginaredirect.Value = "Orden.aspx?Corpo=" + pCorpo.ToString() + "&Central=" + pCentral + "&Oper=" + pOperador + "&Tel=" + pTelefono + "&Suc=" + pSucursal + "&IdCli=" + pIdCliente.ToString() + " &IdDir=" + pIdDireccion.ToString() + "&HoraI=" + pHoraInicio.ToString("hh:mm:ss tt") + "&rfc=" + pRFC; 

            lblModalTitle.Text = "Bluekey Order System";
            lblModalBody.Text = "Requiere Factura ?";
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "myModal", "$('#myModal').modal();", true);
            upModal.Update();
            
            
        }

        private void populateMenu()
        {
            DataTable tblCorp = new DataTable();
            DataTable tblCent = new DataTable();
            DataTable tblOper = new DataTable();
            DataTable tblClie = new DataTable();

            BOS_Corporativo objCorp = new BOS_Corporativo();
            objCorp.Corporativo = pCorpo;
            tblCorp = objCorp.mgetConsultaCorporativo();
            if (tblCorp.Rows.Count > 0 )
            frmCorpo = tblCorp.Rows[0]["Nombre Corporativo"].ToString();

            BOS_Central objCent = new BOS_Central();
            objCent.Corporativo = pCorpo;
            objCent.Central = pCentral;
            tblCent = objCent.mgetConsultaCentral();
            if (tblCent.Rows.Count > 0)
                frmCentral = tblCent.Rows[0]["Nombre Central"].ToString();
                       
            BOS_Operador objOper = new BOS_Operador();
            objOper.Corporativo = pCorpo;
            objOper.Central = pCentral;
            objOper.Operador = pOperador;
            tblOper = objOper.mgetConsultaOperador();
            if (tblOper.Rows.Count > 0)
                frmOperador = tblOper.Rows[0]["Nombre"].ToString();

            BOS_ClienteDireccion objCli = new BOS_ClienteDireccion();
            objCli.Corporativo = pCorpo;
            objCli.Id_Cliente = pIdCliente;
            objCli.Id_Direccion = pIdDireccion;
            tblClie = objCli.mgetConsultaClienteDireccion();

            if (tblClie.Rows.Count > 0)
            {
                frmCliente = tblClie.Rows[0]["Nombre"].ToString() + " " + tblClie.Rows[0]["Apellido"].ToString();
            }
            else { frmCliente = "<strong>Registrar Cliente!</strong>"; }

            frmTelefono = pTelefono;
            pHoraInicio = DateTime.Parse(HttpContext.Current.Session["sHoraInicio"].ToString());
            frmHoraIni = pHoraInicio.ToString("hh:mm:ss tt");

        }

        //private void populateGenerales()
        //{
        //    DataTable dtable = new DataTable();
        //    BOS_Sucursal objSuc = new BOS_Sucursal();
        //    objSuc.Corporativo = pCorpo;
        //    objSuc.Central = pCentral;
        //    objSuc.Sucursal = pSucursal;
        //    dtable = objSuc.mgetConsultaSucursales();
        //    if (dtable.Rows.Count > 0)
        //    {
        //        lblSucE.Text = dtable.Rows[0]["NombreSucursal"].ToString();

        //    }

        //}

        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            bool proceso = false;
            try
            {
                BOS_DatosFactura objDFac = new BOS_DatosFactura();
                objDFac.Corporativo = pCorpo;
                objDFac.RFC = txtRFC.Text;
                objDFac.Codigo_Postal = txtCP.Text;
                objDFac.Razon_Social = txtRazon.Text;
                objDFac.Nombre_Comercial = txtNom.Text;
                objDFac.Calle = txtCalle.Text;
                objDFac.No_Exterior = txtNumE.Text;
                objDFac.No_Interior = txtNumI.Text;
                objDFac.Colonia = txtCol.Text;
                objDFac.Municipio = txtMpio.Text;
                objDFac.Estado = txtEdo.Text;
                objDFac.Pais = txtPais.Text;

                proceso = objDFac.insertaDatosFiscales();

                if (proceso==true)
                {
                    Session["sRFC"] = txtRFC.Text;
                    lblMsgAlert.Text = "Se registro correctamente su RFC<strong>" + txtRFC.Text +"</strong>";
                    Message.CssClass = String.Format("alert alert-{0} alert-dismissable", Alertas.AlertasType.Info.ToString().ToLower());
                    Message.Attributes.Add("role", "alert");

                    //showMessage("", "", "Su registro se guardo correctamente.");
                    //Response.Redirect("Orden.aspx?Corpo=" + pCorpo.ToString() + "&Central=" + pCentral + "&Oper=" + pOperador + "&Suc=" + pSucursal + "&IdCli=" + pIdCliente.ToString() + " &IdDir=" + pIdDireccion.ToString());
                }                

            }
            catch (Exception Ex)
            {
                String A = Ex.Message;
                String B = Ex.Source;
                showMessage(A, B, "Error al insertar datos cliente");
            }

        }

        protected void btnOrden_Click(object sender, EventArgs e)
        {
            //actualiza rfc a la orden
            var orden = listaOrden.FirstOrDefault();
            orden.RFC = txtRFC.Text;
            orden.Codigo_Postal = txtCP.Text;

            Response.Redirect("Empty.aspx");


            //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Bluekey Message", "alert('Su pedido ha sido enviado y finalizado!')", true);
            //cierre de app
            //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Bluekey Message", "window.onunload = CloseWindow();", true);
            //Page.ClientScript.RegisterOnSubmitStatement(typeof(Page), "closePage", "window.onunload = CloseWindow();");


        }

      

        protected void btnBuscar_Click(object sender, ImageClickEventArgs e)
        {
            if (txtRFC.Text != "")
            {

                DataTable dtable = new DataTable();
                BOS_DatosFactura objDfac = new BOS_DatosFactura();
                objDfac.Corporativo = pCorpo;
                objDfac.RFC = txtRFC.Text;
                dtable = objDfac.mgetConsultaDatosFiscales();

                if (dtable.Rows.Count > 0)
                {
                    txtRFC.Text = dtable.Rows[0]["RFC"].ToString();
                    txtCP.Text = dtable.Rows[0]["Codigo Postal"].ToString();
                    txtRazon.Text = dtable.Rows[0]["Razon Social"].ToString();
                    txtNom.Text = dtable.Rows[0]["Nombre Comercial"].ToString();
                    txtCalle.Text = dtable.Rows[0]["Calle"].ToString();
                    txtNumE.Text = dtable.Rows[0]["No Exterior"].ToString();
                    txtNumI.Text = dtable.Rows[0]["No Interior"].ToString();
                    txtCol.Text = dtable.Rows[0]["Colonia"].ToString();
                    txtMpio.Text = dtable.Rows[0]["Municipio"].ToString();
                    txtEdo.Text = dtable.Rows[0]["Estado"].ToString();
                    txtPais.Text = dtable.Rows[0]["Pais"].ToString();
                    Session["sRFC"] = txtRFC.Text;
                }
                else
                {
                    lblMsgAlert.Text = "<strong>No se encontraron coincidencias con su busqueda, registre RFC.</strong>";
                    Message.CssClass = String.Format("alert alert-{0} alert-dismissable", Alertas.AlertasType.Warning.ToString().ToLower());
                    Message.Attributes.Add("role", "alert");

                }
            }
            else {
                lblMsgAlert.Text = "<strong>Ingrese un RFC para realizar la busqueda.</strong>";
                Message.CssClass = String.Format("alert alert-{0} alert-dismissable", Alertas.AlertasType.Warning.ToString().ToLower());
                Message.Attributes.Add("role", "alert");
                txtRFC.Focus();
            }

        }

        private void showMessage(string msgA, string msgB, string St_Mensaje)
        {           
            St_Mensaje = St_Mensaje +"\n" + msgA + "\n" + msgB;
            lblModalTitleError.Text = "Bluekey Order System";
            lblModalBodyError.Text = St_Mensaje;
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "myModal", "$('#myModalError').modal();", true);
            upModalError.Update();

        }

      
    }
}