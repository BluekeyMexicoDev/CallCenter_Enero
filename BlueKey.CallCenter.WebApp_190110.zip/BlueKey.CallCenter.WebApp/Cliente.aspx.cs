﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Bluekey.CallCenter.BusinessRule;


namespace BlueKey.CallCenter.WebApp
{
    public partial class Cliente : System.Web.UI.Page
    {
        int pCorpo;
        string pCentral;
        string pOrigen;
        string pOperador;
        string pTelefono;
        string pSucursal;
        string pResidencia;
        DateTime pHoraInicio;
        int pIdCliente;
        int pIdDireccion;
        string pCP;
        string pEstado;
        string pMunicipio;
        string pColonia;
        
        private string frmCorpo;
        protected string _frmCorpo { get { return frmCorpo; } }

        private string frmCentral;
        protected string _frmCentral { get { return frmCentral; } }

        private string frmTelefono;
        protected string _frmTelefono { get { return frmTelefono; } }

        private string frmOperador;
        protected string _frmOperador { get { return frmOperador; } }

        private string frmCliente;
        protected string _frmCliente { get { return frmCliente; } }

        private string frmHoraIni;
        protected string _frmHoraIni { get { return frmHoraIni; } }

        protected void Page_Load(object sender, EventArgs e)
        {           
            txtTel.Attributes.Add("onKeyPress", "return soloNumeros(event);");
            txtCel.Attributes.Add("onKeyPress", "return soloNumeros(event);");
            txtCP.Attributes.Add("onKeyPress", "return soloNumeros(event);");
            //currentTime.InnerText = DateTime.Now.AddHours(1).ToString("T");
          

            if (!IsPostBack)
            {
                getLoadQS();
                populateMenu();
                populateDirecciones();
                //populateSucursales();
                populateResidencias();
                //pupulateCodigosPostales();
                populateSeleccion();
                //populateFechaNac();
            }
            else
            {

                pCorpo = int.Parse(HttpContext.Current.Session["sCorpo"].ToString());
                pCentral = HttpContext.Current.Session["sCentral"].ToString();
                pOrigen = HttpContext.Current.Session["sOrigen"].ToString();
                pOperador = HttpContext.Current.Session["sOperador"].ToString();
                pTelefono = HttpContext.Current.Session["sTelefono"].ToString();
                pHoraInicio = DateTime.Parse(HttpContext.Current.Session["sHoraInicio"].ToString());

                if (HttpContext.Current.Session["sCP"] != null)
                    pCP = HttpContext.Current.Session["sCP"].ToString();

                if (HttpContext.Current.Session["sEstado"] != null )
                    pEstado= HttpContext.Current.Session["sEstado"].ToString();

                if (HttpContext.Current.Session["sMunicipio"] != null)
                    pMunicipio = HttpContext.Current.Session["sMunicipio"].ToString();

                if (HttpContext.Current.Session["sColonia"] != null)
                    pColonia =  HttpContext.Current.Session["sColonia"].ToString();
               
            }
        }

      

        private void getLoadQS()
        {
            pCorpo = int.Parse(Request.QueryString["Corpo"].ToString());
            pCentral = Request.QueryString["Central"];
            pOrigen = Request.QueryString["Ori"];
            pOperador = Request.QueryString["Oper"];
            pTelefono = Request.QueryString["Tel"];
      

            Session["sCorpo"] = pCorpo;
            Session["sCentral"] = pCentral;
            Session["sOrigen"] = pOrigen;
            Session["sOperador"] = pOperador;
            Session["sTelefono"] = pTelefono;


        }

        private void populateMenu()
        {
            DataTable tblCorp = new DataTable();
            DataTable tblCent = new DataTable();
            DataTable tblOper = new DataTable();
            DataTable tblClie = new DataTable();

            BOS_Corporativo objCorp = new BOS_Corporativo();
            objCorp.Corporativo = pCorpo;
            tblCorp = objCorp.mgetConsultaCorporativo();
            if (tblCorp.Rows.Count > 0)
            {
                frmCorpo = tblCorp.Rows[0]["Nombre Corporativo"].ToString();
            } else { frmCorpo = "No se pudo obtener corporativo"; }
                

            BOS_Central objCent = new BOS_Central();
            objCent.Corporativo = pCorpo;
            objCent.Central = pCentral;
            tblCent = objCent.mgetConsultaCentral();
            if (tblCent.Rows.Count > 0)
            { frmCentral = tblCent.Rows[0]["Nombre Central"].ToString(); }
            else { frmCentral = "No se pudo ontener central"; }
            

            BOS_Operador objOper = new BOS_Operador();
            objOper.Corporativo = pCorpo;
            objOper.Central = pCentral;
            objOper.Operador = pOperador;
            tblOper = objOper.mgetConsultaOperador();
            if (tblOper.Rows.Count > 0 ) 
            {
                frmOperador = tblOper.Rows[0]["Nombre"].ToString();
            }
            else { frmOperador = "No se pudo obtener operador"; }
           

            BOS_Cliente objClie = new BOS_Cliente();
            objClie.Corporativo = pCorpo;
            objClie.Telefono_Cliente = pTelefono;
            objClie.Opcion = 0;
            objClie.Filtro = "";
            tblClie = objClie.mgetConsultaClienteDirecciones();

            if (tblClie.Rows.Count > 0)
            {
                frmCliente = tblClie.Rows[0]["Nombre"].ToString();
            }
            else { frmCliente = "<strong>Registrar Cliente!</strong>"; }

            frmTelefono = pTelefono;

            if (pHoraInicio != null)
                pHoraInicio = DateTime.Now.AddHours(1);


            Session["sHoraInicio"] = pHoraInicio.ToString("hh:mm:ss tt");
            frmHoraIni = pHoraInicio.ToString("hh:mm:ss tt");


        }

        private void populateDirecciones()
        {
            DataTable tblCliente = new DataTable();
            BOS_Cliente objCliente = new BOS_Cliente();
            objCliente.Corporativo = pCorpo;
            objCliente.Telefono_Cliente = pTelefono;
            objCliente.Opcion = 0;
            objCliente.Filtro = "";
            tblCliente = objCliente.mgetConsultaClienteDirecciones();

            if (tblCliente.Rows.Count > 0 )
            { 
                grdDir.DataSource = tblCliente;
                grdDir.DataBind();
            }
        }

        private void populateSucursales()
        {
            DataTable tblSuc = new DataTable();
            BOS_Sucursal objSuc = new BOS_Sucursal();
            objSuc.Corporativo = pCorpo;
            objSuc.Central = pCentral;
            objSuc.Codigo_Postal = pCP;
            tblSuc = objSuc.mgetConsultaSucursalesDespacho();
            if (tblSuc.Rows.Count > 0)
            {

                ddlSuc.Items.Clear();
                ddlSuc.Items.Add(new ListItem { Text = "Seleccione Sucursal", Value = "" });
                ddlSuc.AppendDataBoundItems = true;
                ddlSuc.DataSource = tblSuc;
                ddlSuc.DataTextField = "NombreSucursal";
                ddlSuc.DataValueField = "Sucursal";
                ddlSuc.DataBind();
            }
            else
            {
                ddlSuc.Items.Clear();
                ddlSuc.Items.Add(new ListItem { Text = "Seleccione Sucursal", Value = "" });

            }
            //else
            //{
            //    lblMsgAlert.Text = "<strong>Actualmente no hay sucursales disponibles para el codigo postal seleccinado!</strong>";
            //    Message.CssClass = String.Format("alert alert-{0} alert-dismissable", Alertas.AlertasType.Warning.ToString().ToLower());
            //    Message.Attributes.Add("role", "alert");
            
            //}


        }

        private void populateResidencias()
        {
            DataTable tblRes = new DataTable();
            BOS_Residencia objRes = new BOS_Residencia();
            objRes.Corporativo = pCorpo;
            tblRes = objRes.mgetConsultaResidencia();

            if (tblRes.Rows.Count > 0)
            {
                ddlRes.Items.Clear();
                ddlRes.Items.Add(new ListItem { Text = "Seleccione Residencia", Value = "" });
                ddlRes.AppendDataBoundItems = true;
                ddlRes.DataSource = tblRes;
                ddlRes.DataTextField = "NombreResidencia";
                ddlRes.DataValueField = "Residencia";
                ddlRes.DataBind();

            }

        }

        //private void pupulateCodigosPostales()
        //{
        //    DataTable tblCP = new DataTable();
        //    BOS_CodigoPostal objCP = new BOS_CodigoPostal();
        //    objCP.Opcion = 1;
        //    objCP.Corporativo = pCorpo;
        //    objCP.CodigoPostal = "";
        //    objCP.Estado = "";
        //    objCP.Municipio = "";
        //    tblCP = objCP.mgetConsultaCodigoPostal();

        //    if (tblCP.Rows.Count > 0)
        //    {
        //        ddlCP.Items.Clear();
        //        ddlCP.Items.Add(new ListItem { Text = "Seleccione Codigo Postal", Value = "" });
        //        ddlCP.AppendDataBoundItems = true;
        //        ddlCP.DataSource = tblCP;
        //        ddlCP.DataTextField = "CodigoPostal";
        //        ddlCP.DataValueField = "CodigoPostal";
        //        ddlCP.DataBind();
            
        //    }       



        //}

        //private void populateEstados()
        //{
        //    DataTable tblCP = new DataTable();
        //    BOS_CodigoPostal objCP = new BOS_CodigoPostal();
        //    objCP.Opcion = 2;
        //    objCP.Corporativo = pCorpo;
        //    objCP.CodigoPostal = pCP;
        //    objCP.Estado = "";
        //    objCP.Municipio = "";
        //    tblCP = objCP.mgetConsultaCodigoPostal();

        //    if (tblCP.Rows.Count > 0)
        //    {
        //        ddlEdo.Items.Clear();
        //        ddlEdo.Items.Add(new ListItem { Text = "Seleccione Estado", Value = "" });
        //        ddlEdo.AppendDataBoundItems = true;
        //        ddlEdo.DataSource = tblCP;
        //        ddlEdo.DataTextField = "Estado";
        //        ddlEdo.DataValueField = "Estado";
        //        ddlEdo.DataBind();

        //    }       
        //}

        //private void populateMunicipios()
        //{
        //    DataTable tblCP = new DataTable();
        //    BOS_CodigoPostal objCP = new BOS_CodigoPostal();
        //    objCP.Opcion = 3;
        //    objCP.Corporativo = pCorpo;
        //    objCP.CodigoPostal = pCP;
        //    objCP.Estado = pEstado;
        //    objCP.Municipio = "";
        //    tblCP = objCP.mgetConsultaCodigoPostal();

        //    if (tblCP.Rows.Count > 0)
        //    {

        //        ddlMpio.Items.Clear();
        //        ddlMpio.Items.Add(new ListItem { Text = "Seleccione Municipio", Value = "" });
        //        ddlMpio.AppendDataBoundItems = true;
        //        ddlMpio.DataSource = tblCP;
        //        ddlMpio.DataTextField = "Municipio";
        //        ddlMpio.DataValueField = "Municipio";
        //        ddlMpio.DataBind();

        //    }       
        //}

        private void populateColonias()
        {
            DataTable tblCP = new DataTable();
            BOS_CodigoPostal objCP = new BOS_CodigoPostal();
            objCP.Opcion = 2;
            objCP.Corporativo = pCorpo;
            objCP.CodigoPostal = pCP;
            objCP.Estado = pEstado;
            objCP.Municipio = pMunicipio;
            tblCP = objCP.mgetConsultaCodigoPostal();

            if (tblCP.Rows.Count > 0)
            {

                ddlCol.Items.Clear();
                ddlCol.Items.Add(new ListItem { Text = "Seleccione Colonia", Value = "" });
                ddlCol.AppendDataBoundItems = true;
                ddlCol.DataSource = tblCP;
                ddlCol.DataTextField = "Colonia";
                ddlCol.DataValueField = "Colonia";
                ddlCol.DataBind();

            }       
            
        }

        private void populateSeleccion()
        {
            //ddlEdo.Items.Clear();
            //ddlEdo.Items.Add(new ListItem { Text = "Seleccione Estado", Value = "" });
            //ddlEdo.AppendDataBoundItems = true;          

            //ddlMpio.Items.Clear();
            //ddlMpio.Items.Add(new ListItem { Text = "Seleccione Municipio", Value = "" });
            //ddlMpio.AppendDataBoundItems = true;

            ddlCol.Items.Clear();
            ddlCol.Items.Add(new ListItem { Text = "Seleccione Colonia", Value = "" });
            ddlCol.AppendDataBoundItems = true;

            ddlSuc.Items.Clear();
            ddlSuc.Items.Add(new ListItem { Text = "Seleccione Sucursal", Value = "" });
            ddlSuc.AppendDataBoundItems = true;
        }

       

       
      
        //private void populateFechaNac()
        //{


        //    ddlDia.Items.Clear();
        //    ddlDia.Items.Add(new ListItem { Text = "Dia", Value = "" });
        //    for (int  i = 1; i<32; i++ )
        //    {
        //        ddlDia.Items.Add(new ListItem { Text = i.ToString(), Value = i.ToString() });
        //    }

        //    ddlMes.Items.Clear();
        //    ddlMes.Items.Add(new ListItem { Text = "Mes",      Value = "" });
        //    ddlMes.Items.Add(new ListItem { Text = "Enero",    Value = "01" });
        //    ddlMes.Items.Add(new ListItem { Text = "Febrero",  Value = "02" });
        //    ddlMes.Items.Add(new ListItem { Text = "Marzo",    Value = "03" });
        //    ddlMes.Items.Add(new ListItem { Text = "Abril",    Value = "04" });
        //    ddlMes.Items.Add(new ListItem { Text = "Mayo",     Value = "05" });
        //    ddlMes.Items.Add(new ListItem { Text = "Junio",    Value = "06" });
        //    ddlMes.Items.Add(new ListItem { Text = "Julio",    Value = "07" });
        //    ddlMes.Items.Add(new ListItem { Text = "Agosto",   Value = "08" });
        //    ddlMes.Items.Add(new ListItem { Text = "Septiembre",Value = "09" });
        //    ddlMes.Items.Add(new ListItem { Text = "Octubre",  Value = "10" });
        //    ddlMes.Items.Add(new ListItem { Text = "Noviembre",Value = "11" });
        //    ddlMes.Items.Add(new ListItem { Text = "Diciembre",Value = "12" });


        //    int aniofin = 0;
        //    aniofin = int.Parse(DateTime.Now.Year.ToString());
        //    ddlAnio.Items.Clear();
        //    ddlAnio.Items.Add(new ListItem { Text = "Año", Value = "" });
        //    for (int k = 1900; k < aniofin - 10; k++)
        //    {
        //        ddlAnio.Items.Add(new ListItem { Text = k.ToString (), Value = k.ToString()});

        //    }

        //}

        protected void ddlSuc_SelectedIndexChanged(object sender, EventArgs e)
        {
            pSucursal = ddlSuc.SelectedItem.Value.ToString();
            Session["sSucursal"] = pSucursal;

            if (pSucursal == "")
            {
                lblMsgAlert.Text = "<strong>Debe seleccionar una sucursal!</strong>";
                Message.CssClass = String.Format("alert alert-{0} alert-dismissable", Alertas.AlertasType.Warning.ToString().ToLower());
                Message.Attributes.Add("role", "alert");
            }
            else {            

                //lblMsgAlert.Text ="Envio a sucursal: <strong>" + ddlSuc.SelectedItem.Text  + "</strong>";
                //Message.CssClass = String.Format("alert alert-{0} alert-dismissable", Alertas.AlertasType.Info.ToString().ToLower());
                //Message.Attributes.Add("role", "alert");

                showMessageAlerts("Su pedido se enviará a la sucursal: <strong>" + ddlSuc.SelectedItem.Text + "</strong>");
            }
        }

        protected void ddlRes_SelectedIndexChanged(object sender, EventArgs e)
        {
            pResidencia = ddlRes.SelectedItem.Value.ToString();
            Session["sResidencia"] = pResidencia;
        }

        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            bool edita = false;
            int idCliente = 0;
            int idClienteDireccion = 0;
            int proceso = 0;
            BOS_Cliente objCliente = new BOS_Cliente();
            BOS_ClienteDireccion objCliDir = new BOS_ClienteDireccion();
            //pSucursal = HttpContext.Current.Session["sSucursal"].ToString();
            pResidencia = HttpContext.Current.Session["sResidencia"].ToString();

            try
            {
                if (HttpContext.Current.Session["sEditEnable"] != null)
                    edita = bool.Parse(HttpContext.Current.Session["sEditEnable"].ToString());

                if (edita == false)
                {
                    objCliente.Corporativo = pCorpo;
                    objCliente.Telefono_Cliente = pTelefono;
                    objCliente.Telefono_Celular = txtCel.Text;
                    objCliente.Telefono_Extra = txtTel.Text;
                    objCliente.Nombre = txtNombre.Text;
                    objCliente.Apellido = txtApellido.Text;
                    objCliente.Email = txtEmail.Text;
                    objCliente.Fecha_Nacimiento = txtFec.Text;
                    idCliente = objCliente.insertaCliente();
                    Session["sIdCli"] = idCliente;

                    objCliDir.Corporativo = pCorpo;
                    objCliDir.Id_Cliente = idCliente;
                    objCliDir.Residencia = pResidencia;
                    objCliDir.Codigo_Postal = pCP;
                    objCliDir.Calle = txtCalle.Text;
                    objCliDir.No_Exterior = txtNumE.Text;
                    objCliDir.No_Interior = txtNumI.Text;
                    objCliDir.Colonia = pColonia;
                    objCliDir.Municipio = txtMpio.Text;
                    objCliDir.Estado = txtEdo.Text;
                    objCliDir.Entre_Calles = txtEnt.Text;
                    objCliDir.Referencia = txtRef.Text;
                    idClienteDireccion = objCliDir.insertaClienteDireccion();
                    Session["sIdDir"] = idClienteDireccion;


                    //lblMsgAlert.Text = "Cliente registrado: <strong>" + txtNombre.Text + " " + txtApellido.Text + "</strong>";
                    //Message.CssClass = String.Format("alert alert-{0} alert-dismissable", Alertas.AlertasType.Success.ToString().ToLower());
                    //Message.Attributes.Add("role", "alert");

                    showMessageAlerts("Cliente registrado: <strong>" + txtNombre.Text + " " + txtApellido.Text + "</strong>");
                }
                else
                {
                    idCliente = int.Parse(HttpContext.Current.Session["sIdCli"].ToString());

                    objCliente.Corporativo = pCorpo;
                    objCliente.Id_Cliente = idCliente;
                    objCliente.Telefono_Cliente = pTelefono;
                    objCliente.Telefono_Celular = txtCel.Text;
                    objCliente.Telefono_Extra = txtTel.Text;
                    objCliente.Nombre = txtNombre.Text;
                    objCliente.Apellido = txtApellido.Text;
                    objCliente.Email = txtEmail.Text;
                    objCliente.Fecha_Nacimiento = txtFec.Text;
                    proceso = objCliente.actualizaCliente();

                    idClienteDireccion = int.Parse(HttpContext.Current.Session["sIdDir"].ToString());
                    objCliDir.Corporativo = pCorpo;
                    objCliDir.Id_Cliente = idCliente;
                    objCliDir.Id_Direccion = idClienteDireccion;
                    objCliDir.Residencia = ddlRes.SelectedItem.Value.ToString();
                    objCliDir.Codigo_Postal = txtCP.Text;
                    objCliDir.Calle = txtCalle.Text;
                    objCliDir.No_Exterior = txtNumE.Text;
                    objCliDir.No_Interior = txtNumI.Text;
                    objCliDir.Colonia = ddlCol.SelectedItem.Value.ToString();
                    objCliDir.Municipio = txtMpio.Text;
                    objCliDir.Estado = txtEdo.Text;
                    objCliDir.Entre_Calles = txtEnt.Text;
                    objCliDir.Referencia = txtRef.Text;
                    proceso = objCliDir.actualizaClienteDireccion();

                    Session["sEditEnable"] = null;

                    blockControls();
                    populateDirecciones();
                    

                    //lblMsgAlert.Text = "Cliente actualizado: <strong>" + txtNombre.Text + " " + txtApellido.Text + "</strong>";
                    //Message.CssClass = String.Format("alert alert-{0} alert-dismissable", Alertas.AlertasType.Success.ToString().ToLower());
                    //Message.Attributes.Add("role", "alert");

                    showMessageAlerts("Cliente actualizado: <strong>" + txtNombre.Text + " " + txtApellido.Text + "</strong>");
                }

              


            }
            catch (Exception Ex)
            {
                String A = Ex.Message;
                String B = Ex.Source;
                showMessage(A, B, "Error al insertar datos del Cliente");

            }


        }

        private void showMessage(string msgA, string msgB, string title)
        {
            String St_Mensaje = "";
            St_Mensaje = "Error al insertar datos cliente \n" + msgA + "\n" + msgB;
            lblModalTitle.Text = "Bluekey Order System";
            lblModalBody.Text = St_Mensaje;
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "myModal", "$('#myModal').modal();", true);
            upModal.Update();

        }

        private void showMessageAlerts(string msgA)
        {            
            lblModalTitle.Text = "Bluekey Order System";
            lblModalBody.Text = msgA;
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "myModal", "$('#myModal').modal();", true);
            upModal.Update();

        }

        protected void btnOrden_Click(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["sSucursal"] != null)
            { pSucursal = HttpContext.Current.Session["sSucursal"].ToString(); }
            else { pSucursal = ""; }
            if (HttpContext.Current.Session["sIdCli"] != null)
            { pIdCliente = int.Parse(HttpContext.Current.Session["sIdCli"].ToString()); }
            else { pIdCliente = 0; }
            if (HttpContext.Current.Session["sIdDir"] != null)
            { pIdDireccion = int.Parse(HttpContext.Current.Session["sIdDir"].ToString()); }
            else { pIdDireccion = 0; }
            

            if (pIdCliente == 0 && pIdDireccion == 0)
            {
                lblMsgAlert.Text = "<strong>Debe seleccionar un cliente!</strong>";
                Message.CssClass = String.Format("alert alert-{0} alert-dismissable", Alertas.AlertasType.Danger.ToString().ToLower());
                Message.Attributes.Add("role", "alert");
            }
            else if (pSucursal == "" || pSucursal == null)
            {
                lblMsgAlert.Text = "<strong>Debe seleccionar una sucursal!</strong>";
                Message.CssClass = String.Format("alert alert-{0} alert-dismissable", Alertas.AlertasType.Danger.ToString().ToLower());
                Message.Attributes.Add("role", "alert");                
            }
            else
            {

                Response.Redirect("Orden.aspx?Corpo=" + pCorpo.ToString() + "&Central=" + pCentral + "&Ori=" + pOrigen + " &Oper=" + pOperador  + "&Tel=" + pTelefono + "&Suc=" + pSucursal + " &IdCli=" + pIdCliente.ToString() + "&IdDir=" + pIdDireccion.ToString() + "&HoraI=" + pHoraInicio.ToString("hh:mm:ss tt"));
                //Response.Redirect("DatosFiscales.aspx?Corpo=" + pCorpo.ToString () + "&Central=" + pCentral + "&Oper=" + pOperador + "&Tel="+ pTelefono + "&Suc=" + pSucursal + " &IdCli=" + pIdCliente.ToString() + "&IdDir=" + pIdDireccion.ToString() + "&HoraI=" + pHoraInicio.ToString("hh:mm:ss tt")+ "&rfc=" + pRFC);
                //Response.Redirect("DatosFiscales.aspx?Corpo=1&Central=cdmx&Oper=1mx0004&Tel=88&Suc=Sate&IdCli=8&IdDir=1&HoraI=" + pHoraInicio.ToString("hh:mm tt"));
            }

           
        }

        private void limpiaInputs()
        {
            txtCel.Text = "";
            txtTel.Text = "";
            txtNombre.Text = "";
            txtApellido.Text = "";
            txtEmail.Text = "";
            txtFec.Text = "";
            txtCP.Text = "";
            //ddlCP.ClearSelection();
            txtCalle.Text = "";
            txtNumE.Text = "";
            txtNumI.Text = "";
            ddlCol.ClearSelection();
            txtEdo.Text = "";
            txtMpio.Text = "";
            //ddlMpio.ClearSelection();
            //ddlEdo.ClearSelection();
            txtEnt.Text = "";
            txtRef.Text = "";

            ddlRes.ClearSelection();

            ddlCol.Items.Clear();
            ddlCol.Items.Add(new ListItem { Text = "Seleccione Colonia", Value = "" });
            ddlCol.AppendDataBoundItems = true;

            ddlSuc.Items.Clear();
            ddlSuc.Items.Add(new ListItem { Text = "Seleccione Sucursal", Value = "" });
            ddlSuc.AppendDataBoundItems = true;


        }

        protected void grdDir_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int idCliente;
            int idDireccion;           

            limpiaInputs();

            DataTable tblClie = new DataTable();

            //var index = e.CommandArgument;
            idCliente = int.Parse(grdDir.Rows[int.Parse(e.CommandArgument.ToString())].Cells[0].Text);
            idDireccion = int.Parse(grdDir.Rows[int.Parse(e.CommandArgument.ToString())].Cells[1].Text);

            //GridViewRow row = grdDir.SelectedRow;
            //idCliente = int.Parse(row.Cells[0].Text);
            //idDireccion = int.Parse(row.Cells[1].Text);


            try
            {

                BOS_ClienteDireccion objClie = new BOS_ClienteDireccion();
                objClie.Corporativo = pCorpo;
                objClie.Id_Cliente = idCliente;
                objClie.Id_Direccion = idDireccion;
                tblClie = objClie.mgetConsultaClienteDireccion();
                               

                if (tblClie.Rows.Count > 0)
                {
                    //aqui poblar combos..
                    pEstado = tblClie.Rows[0]["Estado"].ToString();
                    pMunicipio = tblClie.Rows[0]["Municipio"].ToString();
                    pCP = tblClie.Rows[0]["CP"].ToString();
                    
                    //pupulateCodigosPostales();
                    //populateEstados();
                    //populateMunicipios();
                    populateColonias();
                    populateSucursales();

                    pIdCliente = int.Parse(tblClie.Rows[0]["idCliente"].ToString());
                    pIdDireccion = int.Parse(tblClie.Rows[0]["idDireccion"].ToString());
                    txtCP.Text = pCP;
                    txtCel.Text = tblClie.Rows[0]["TelefonoCelular"].ToString();
                    txtTel.Text = tblClie.Rows[0]["TelefonoExtra"].ToString();
                    txtNombre.Text = tblClie.Rows[0]["Nombre"].ToString();
                    txtApellido.Text = tblClie.Rows[0]["Apellido"].ToString();
                    txtEmail.Text = tblClie.Rows[0]["Email"].ToString();
                    txtFec.Text = tblClie.Rows[0]["FechaNacimiento"].ToString();
                    //ddlCP.SelectedValue = tblClie.Rows[0]["CP"].ToString();
                    txtCalle.Text = tblClie.Rows[0]["Calle"].ToString();
                    txtNumE.Text = tblClie.Rows[0]["NoExt"].ToString();
                    txtNumI.Text = tblClie.Rows[0]["NoInt"].ToString();
                    txtEdo.Text = tblClie.Rows[0]["Estado"].ToString();
                    txtMpio.Text = tblClie.Rows[0]["Municipio"].ToString();
                    //ddlEdo.SelectedValue = tblClie.Rows[0]["Estado"].ToString();                   
                    //ddlMpio.SelectedValue = tblClie.Rows[0]["Municipio"].ToString();
                    ddlCol.SelectedValue = tblClie.Rows[0]["Colonia"].ToString();                    
                    txtEnt.Text = tblClie.Rows[0]["EntreCalles"].ToString();
                    txtRef.Text = tblClie.Rows[0]["Referencia"].ToString();
                    ddlRes.SelectedValue = tblClie.Rows[0]["Residencia"].ToString();

                    Session["sResidencia"] = tblClie.Rows[0]["Residencia"].ToString();
                    Session["sIdCli"] = pIdCliente;
                    Session["sIdDir"] = pIdDireccion;

                    //lblMsgAlert.Text = "Selecciono  los datos de: <strong>" + tblClie.Rows[0]["Nombre"].ToString() + " " + tblClie.Rows[0]["Apellido"].ToString() +"</strong>";
                    //Message.CssClass = String.Format("alert alert-{0} alert-dismissable", Alertas.AlertasType.Success.ToString().ToLower());
                    //Message.Attributes.Add("role", "alert");
                                        
                    showMessageAlerts("Selecciono  los datos de: <strong>" + tblClie.Rows[0]["Nombre"].ToString() + " " + tblClie.Rows[0]["Apellido"].ToString() + "</strong>");
                    blockControls();

                }
                else
                {
                    showMessage("", "", "Error al cargar datos del Cliente");
                }
            }              

            catch (Exception Ex)
            {
                String A = Ex.Message;
                String B = Ex.Source;
                showMessage(A, B, "Error al cargar datos del Cliente");

            }
            


        }

        private void blockControls()
        {
            txtCP.Enabled=false;
            txtCel.Enabled = false;
            txtTel.Enabled = false;
            txtNombre.Enabled = false;
            txtApellido.Enabled = false;
            txtEmail.Enabled = false;
            txtFec.Enabled = false;
            txtCalle.Enabled = false;
            txtNumE.Enabled = false;
            txtNumI.Enabled = false;
            txtEnt.Enabled = false;
            txtRef.Enabled = false;
            ddlCol.Enabled = false;
            ddlRes.Enabled = false;
            btnGuardar.Enabled = false; 
                   
        }

        private void enableControls()
        {
            txtCP.Enabled = true;
            txtCel.Enabled = true;
            txtTel.Enabled = true;
            txtNombre.Enabled = true;
            txtApellido.Enabled = true;
            txtEmail.Enabled = true;
            txtFec.Enabled = true;
            txtCalle.Enabled = true;
            txtNumE.Enabled = true;
            txtNumI.Enabled = true;
            txtEnt.Enabled = true;
            txtRef.Enabled = true;
            ddlCol.Enabled = true;
            ddlRes.Enabled = true;
            btnGuardar.Enabled = true;        

        }


        //protected void ddlCP_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    pCP = ddlCP.SelectedItem.Value.ToString();
        //    Session["sCP"] = pCP;
        //    populateEstados();
        //    populateSucursales();
        //}

        //protected void ddlEdo_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    pEstado = ddlEdo.SelectedItem.Value.ToString();
        //    Session["sEstado"] = pEstado;
        //    populateMunicipios();
           
        //}

        //protected void ddlMpio_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    pMunicipio = ddlMpio.SelectedItem.Value.ToString();
        //    Session["sMunicipio"] = pMunicipio;
        //    populateColonias();
          
        //}

        protected void ddlCol_SelectedIndexChanged(object sender, EventArgs e)
        {
            pColonia = ddlCol.SelectedItem.Value.ToString();
            Session["sColonia"] = pColonia;
           
        }

        protected void txtCP_TextChanged(object sender, EventArgs e)
        {
            if (txtCP.Text.Length == 5)
            {
                pCP = txtCP.Text;
                Session["sCP"] = pCP;
                //populateEstados();

                DataTable tblCP = new DataTable();
                BOS_CodigoPostal objCP = new BOS_CodigoPostal();
                objCP.Opcion = 1;
                objCP.Corporativo = pCorpo;
                objCP.CodigoPostal = pCP;
                objCP.Estado = "";
                objCP.Municipio = "";
                tblCP = objCP.mgetConsultaCodigoPostal();

                if (tblCP.Rows.Count > 0)
                {
                    txtEdo.Text = tblCP.Rows[0]["Estado"].ToString();
                    txtMpio.Text = tblCP.Rows[0]["Municipio"].ToString();
                    pEstado = tblCP.Rows[0]["Estado"].ToString();
                    pMunicipio = tblCP.Rows[0]["Municipio"].ToString();

                    populateColonias();
                    populateSucursales();
                    ddlCol.Focus();
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Bluekey Message", "alert('Codigo Postal no existe!')", true);
                    txtCP.Text = "";
                }
               

            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Bluekey Message", "alert('La longitud del código postal deber ser igual a 5')", true);

            }
        }

        protected void btnEditar_Click(object sender, EventArgs e)
        {
            txtUser.Text = "";
            txtPwd.Text = "";
            if (txtNombre.Text !=""){
                modalExtAutEdicion.Show(); 
            }else{
                showMessageAlerts("Seleccione una registro para poder editarlo.");
            }
                           
          
        }

         protected void btnAutSi_Click (object sender, EventArgs e)
        {
            DataTable dtable = new DataTable();
            BOS_Usuario objUsu = new BOS_Usuario();
            objUsu.Corporativo = pCorpo;
            objUsu.Central = pCentral;
            objUsu.Usuario = txtUser.Text;
            objUsu.Contrasena = txtPwd.Text;
            dtable = objUsu.mgetConsultaUsuarioPerfil();

            if (dtable.Rows.Count > 0 && bool.Parse(dtable.Rows[0]["Edita Cliente"].ToString()) == true)
            {
                enableControls();
                modalExtAutEdicion.Hide();
                Session["sEditEnable"] = true;
            }
            else {
                Session["sEditEnable"] = false;
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Bluekey Message", "alert('Usuario sin privilegios para editar cliente')", true);
            }

	      
        }
		
		 protected void btnAutNo_Click(object sender, EventArgs e)
        {
            Session["sEditEnable"] = false;
            modalExtAutEdicion.Hide();
        }

         protected void ddlFiltro_SelectedIndexChanged(object sender, EventArgs e)
         {
             Session["sFiltro"] = ddlFiltro.SelectedItem.Value.ToString();

         }

         protected void btnFiltro_Click(object sender, EventArgs e)
         {            
             string filtro = "";
             int opcion = 0;
            
            if (HttpContext.Current.Session["sFiltro"] != null || HttpContext.Current.Session["sFiltro"].ToString() == "")
            {
                filtro = HttpContext.Current.Session["sFiltro"].ToString();

                //if ( .Rows.Count > 0)
                //{


                switch (filtro)
                {
                    case "Nombre":
                        opcion = 1;
                        break;

                    case "Residencia":
                        opcion = 2;
                        break;

                    case "CP":
                        opcion = 3;
                        break;

                    case "Estado":
                        opcion = 4;
                        break;

                    case "Municipio":
                        opcion = 5;
                        break;

                    case "Colonia":
                        opcion = 6;
                        break;

                    default:
                        opcion = 0;
                        break;

                }

                DataTable tblCliente = new DataTable();
                BOS_Cliente objCliente = new BOS_Cliente();
                objCliente.Corporativo = pCorpo;
                objCliente.Telefono_Cliente = pTelefono;
                objCliente.Opcion = opcion;
                objCliente.Filtro = txtBusqueda.Text;
                tblCliente = objCliente.mgetConsultaClienteDirecciones();

                if (tblCliente.Rows.Count > 0)
                {
                    grdDir.DataSource = tblCliente;
                    grdDir.DataBind();
                }

                //}
                //else
                //{
                //      ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Bluekey Message", "alert('No existen registros!')", true);
                //}

            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Bluekey Message", "alert('Seleccione un filtro')", true);
            }
             
             

         }

         protected void btnNuevo_Click(object sender, EventArgs e)
         {             
             limpiaInputs();
             enableControls();
         }

           


       
    }
}