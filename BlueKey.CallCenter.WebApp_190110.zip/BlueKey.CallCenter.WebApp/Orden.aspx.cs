﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Bluekey.CallCenter.BusinessRule;

namespace BlueKey.CallCenter.WebApp
{
    public partial class Orden : System.Web.UI.Page
    {
        int pCorpo;
        string pCentral;
        string pOrigen;
        string pOperador;
        string pTelefono;
        string pSucursal;
        int pIdCliente;
        int pIdDireccion;
        string pRFC;
        DateTime pHoraInicio;
        int pTurno;
        int lineaOrden;
        decimal lineaPrecio;
        int pOrden;
        string pFormaPago;
        string pHoraIOF;
        string pHoraFOF;
        int pMinOF;
        int pMinPOF;
        DateTime pFechaPromesa;
        DateTime pFechaProcesar;
        DateTime pFechaFin;

        //int lineaPlatillo;
        //string lineaNombrePlatillo;
        //int lineaPaquete;
        //int clickGrupo;


        //lista de orden
        public List<BOS_Orden> listaOrden
        {
            get
            {
                if (HttpContext.Current.Session["listaOrden"] == null)
                {
                    HttpContext.Current.Session["listaOrden"] = new List<BOS_Orden>();
                }
                return HttpContext.Current.Session["listaOrden"] as List<BOS_Orden>;
            }
            set
            {
                HttpContext.Current.Session["listaOrden"] = value;
            }

        }


        //lista de platillos orden
        public List<BOS_OrdenDetalle> listaOrdenDetalle
        {
            get
            {
                if (HttpContext.Current.Session["listaOrdenDetalle"] == null)
                {
                    HttpContext.Current.Session["listaOrdenDetalle"] = new List<BOS_OrdenDetalle>();
                }
                return HttpContext.Current.Session["listaOrdenDetalle"] as List<BOS_OrdenDetalle>;
            }
            set
            {
                HttpContext.Current.Session["listaOrdenDetalle"] = value;
            }

        }

        //lista de platillos que se genera para procesar 
        public List<BOS_PlatilloOrden> listaPlatillos
        {
            get
            {
                if (HttpContext.Current.Session["listaPlatillos"] == null)
                {
                    HttpContext.Current.Session["listaPlatillos"] = new List<BOS_PlatilloOrden>();
                }
                return HttpContext.Current.Session["listaPlatillos"] as List<BOS_PlatilloOrden>;
            }

            set
            {
                HttpContext.Current.Session["listaPlatillos"] = value;
            }
        }


        //lista de platillos  de promociones que se reemplazan
        public List<BOS_Reemplaza> listaReemplazo
        {
            get
            {
                if (HttpContext.Current.Session["listaReemplazo"] == null)
                {
                    HttpContext.Current.Session["listaReemplazo"] = new List<BOS_Reemplaza>();
                }
                return HttpContext.Current.Session["listaReemplazo"] as List<BOS_Reemplaza>;
            }

            set
            {
                HttpContext.Current.Session["listaReemplazo"] = value;
            }
        }


        #region variables forma

        private string frmCorpo;
        protected string _frmCorpo { get { return frmCorpo; } }

        private string frmCentral;
        protected string _frmCentral { get { return frmCentral; } }

        private string frmTelefono;
        protected string _frmTelefono { get { return frmTelefono; } }

        private string frmOperador;
        protected string _frmOperador { get { return frmOperador; } }

        private string frmCliente;
        protected string _frmCliente { get { return frmCliente; } }

        private string frmHoraIni;
        protected string _frmHoraIni { get { return frmHoraIni; } }

        private string frmGrupo;
        protected string _frmGrupo { get { return frmGrupo; } }

        private string frmBusqueda;
        protected string _frmBusqueda { get { return frmBusqueda; } }

        private string frmTotPla;
        protected string _frmTotPla { get { return frmTotPla; } }

        private string frmSubTot;
        protected string _frmSubTot { get { return frmSubTot; } }

        private string frmDesc;
        protected string _frmDesc { get { return frmDesc; } }

        private string frmIVA;
        protected string _frmIVA { get { return frmIVA; } }

        private string frmTotal;
        protected string _frmTotal { get { return frmTotal; } }

        private string frmNotas;
        protected string _frmNotas { get { return frmNotas; } }

        #endregion


        protected void Page_Load(object sender, EventArgs e)
        {
            txtBusqueda.Attributes.Add("onKeyPress", "return clickButtonBusqueda(event,'" + btnBuscar.ClientID + "')");
            //txtBusqueda.Attributes.Add("onkeypress", "return soloLetras(event)");
            txtHora.Attributes.Add("onKeyPress", "return soloNumeros(event);");
            txtMinutos.Attributes.Add("onKeyPress", "return soloNumeros(event);");
            //this.txtTel.Attributes.Add("onKeyPress", "return soloNumeros(event);");

            if (!IsPostBack)
            {
                getLoadQS();
                populateMenu();
                populateGenerales();
                populateFormasPago();

                obtieneTurno();
                generaBtnGrupos();
                generaBtnPlatillos();

                agregaOrden();

            }
            else
            {

                pCorpo = int.Parse(HttpContext.Current.Session["sCorpo"].ToString());
                pCentral = HttpContext.Current.Session["sCentral"].ToString();
                pOrigen = HttpContext.Current.Session["sOrigen"].ToString();
                pOperador = HttpContext.Current.Session["sOperador"].ToString();
                pTelefono = HttpContext.Current.Session["sTelefono"].ToString();
                pSucursal = HttpContext.Current.Session["sSucursal"].ToString();
                pIdCliente = int.Parse(HttpContext.Current.Session["sIdCli"].ToString());
                pIdDireccion = int.Parse(HttpContext.Current.Session["sIdDir"].ToString());
                pHoraInicio = DateTime.Parse(HttpContext.Current.Session["sHoraInicio"].ToString());
                //pRFC = HttpContext.Current.Session["sRFC"].ToString();
                pTurno = int.Parse(HttpContext.Current.Session["sTurno"].ToString());

                frmNotas = txtNotasOrden.Text;
                generaBtnGrupos();
                generaBtnPlatillos();

                if (HttpContext.Current.Session["sClickGrupo"] != null)
                    generaBtnPlatillosGrupo();


                if (HttpContext.Current.Session["sClickBusqueda"] != null)
                {
                    foreach (Control item in pnlBusqueda.Controls.OfType<Button>())
                    {
                        pnlBusqueda.Controls.Remove(item);
                    }
                    generaBtnPlatilloBusqueda();
                }

                if (HttpContext.Current.Session["sEquivalencia"] != null)
                {
                    generaPlatilloEquivalencia(int.Parse(HttpContext.Current.Session["sEquivalencia"].ToString()));
                }

                if (HttpContext.Current.Session["sTerminador"] != null)
                {
                    generaPlatilloTerminadores(int.Parse(HttpContext.Current.Session["sTerminador"].ToString()));
                }

                if (HttpContext.Current.Session["sModificador"] != null)
                {
                    generaPlatilloModificadores(int.Parse(HttpContext.Current.Session["sModificador"].ToString()), int.Parse(HttpContext.Current.Session["sModGrupo"].ToString()), HttpContext.Current.Session["sModCla"].ToString());

                }

                if (HttpContext.Current.Session["sReemplazos"] != null)
                {
                    generaReemplazos();

                }

                if (HttpContext.Current.Session["sProcesaPromocion"] != null && HttpContext.Current.Session["sPromoPreguntando"] == null)
                {
                    generaPromociones();

                }

                refreshTotales();


            }
        }

        private void populateFormasPago()
        {
            DataTable dtable = new DataTable();
            BOS_FormasPago objFP = new BOS_FormasPago();
            objFP.Central = pCentral;
            objFP.Corporativo = pCorpo;
            dtable = objFP.mgetConsultaFormasPago();

            if (dtable.Rows.Count > 0)
            {
                ddlFP.Items.Clear();
                ddlFP.Items.Add(new ListItem { Text = "Forma de Pago", Value = "" });
                ddlFP.AppendDataBoundItems = true;
                ddlFP.DataSource = dtable;
                ddlFP.DataTextField = "NombreFormaPago";
                ddlFP.DataValueField = "FormaPago";
                ddlFP.DataBind();

            }


        }




        #region populateMenu

        private void getLoadQS()
        {
            pCorpo = int.Parse(Request.QueryString["Corpo"].ToString());
            pCentral = Request.QueryString["Central"];
            pOrigen = Request.QueryString["Ori"];
            pOperador = Request.QueryString["Oper"];
            pTelefono = Request.QueryString["Tel"];
            pSucursal = Request.QueryString["Suc"];
            pIdCliente = int.Parse(Request.QueryString["IdCli"].ToString());
            pIdDireccion = int.Parse(Request.QueryString["IdDir"].ToString());
            pHoraInicio = DateTime.Parse(Request.QueryString["HoraI"].ToString());
            //pRFC = Request.QueryString["rfc"].ToString();


            Session["sCorpo"] = pCorpo;
            Session["sCentral"] = pCentral;
            Session["sOrigen"] = pOrigen;
            Session["sOperador"] = pOperador;
            Session["sTelefono"] = pTelefono;
            Session["sSucursal"] = pSucursal;
            Session["sIdCli"] = pIdCliente;
            Session["sIdDir"] = pIdDireccion;
            Session["sHoraInicio"] = pHoraInicio;
            //Session["sRFC"] = pRFC;

        }

        protected string ClientIDPageRedirect()
        {
            return this.paginaredirect.ClientID;
        }


        private void populateMenu()
        {
            DataTable tblCorp = new DataTable();
            DataTable tblCent = new DataTable();
            DataTable tblOper = new DataTable();
            DataTable tblClie = new DataTable();

            BOS_Corporativo objCorp = new BOS_Corporativo();
            objCorp.Corporativo = pCorpo;
            tblCorp = objCorp.mgetConsultaCorporativo();
            if (tblCorp.Rows.Count > 0)
            {
                frmCorpo = tblCorp.Rows[0]["Nombre Corporativo"].ToString();
            }
               

            BOS_Central objCent = new BOS_Central();
            objCent.Corporativo = pCorpo;
            objCent.Central = pCentral;
            tblCent = objCent.mgetConsultaCentral();
            if (tblCent.Rows.Count > 0)
            {
                frmCentral = tblCent.Rows[0]["Nombre Central"].ToString();
                hdDOF.Value = tblCent.Rows[0]["DiasOrdenFuturo"].ToString();
                pHoraIOF = tblCent.Rows[0]["HoraInicial"].ToString(); 
                pHoraFOF = tblCent.Rows[0]["HoraFinal"].ToString();
                pMinOF =int.Parse(tblCent.Rows[0]["MinutosOrdenFuturo"].ToString());
                pMinPOF = int.Parse(tblCent.Rows[0]["MinutosProcesaOrdenFuturo"].ToString());
            }
               

            BOS_Operador objOper = new BOS_Operador();
            objOper.Corporativo = pCorpo;
            objOper.Central = pCentral;
            objOper.Operador = pOperador;
            tblClie = objOper.mgetConsultaOperador();
            if (tblClie.Rows.Count > 0)
            {
                frmOperador = tblClie.Rows[0]["Nombre"].ToString();
            }
               

            BOS_ClienteDireccion objCli = new BOS_ClienteDireccion();
            objCli.Corporativo = pCorpo;
            objCli.Id_Cliente = pIdCliente;
            objCli.Id_Direccion = pIdDireccion;
            tblClie = objCli.mgetConsultaClienteDireccion();

            if (tblClie.Rows.Count > 0)
            {
                frmCliente = tblClie.Rows[0]["Nombre"].ToString() + " " + tblClie.Rows[0]["Apellido"].ToString();
            }
            else { frmCliente = "<strong>Registrar Cliente!</strong>"; }

            frmTelefono = pTelefono;
            pHoraInicio = DateTime.Parse(HttpContext.Current.Session["sHoraInicio"].ToString());
            frmHoraIni = pHoraInicio.ToString("hh:mm:ss tt");

        }

        private void populateGenerales()
        {
            DataTable dtable = new DataTable();
            BOS_Sucursal objSuc = new BOS_Sucursal();
            objSuc.Corporativo = pCorpo;
            objSuc.Central = pCentral;
            objSuc.Sucursal = pSucursal;
            dtable = objSuc.mgetConsultaSucursales();
            if (dtable.Rows.Count > 0)
            {
                lblSucE.Text = dtable.Rows[0]["NombreSucursal"].ToString();

            }


        }

        private void obtieneTurno()
        {
            DataTable dtable = new DataTable();
            BOS_Turno objTurno = new BOS_Turno();
            objTurno.Corporativo = pCorpo;
            objTurno.Central = pCentral;
            objTurno.HoraTurno = pHoraInicio.ToString("yyyy-MM-dd HH:mm:ss");

            dtable = objTurno.mgetObtieneTurno();
            if (dtable.Rows.Count > 0)
            {
                pTurno = int.Parse(dtable.Rows[0]["Turno"].ToString());
                lblTurnoE.Text = dtable.Rows[0]["NombreTurno"].ToString();
                Session["sTurno"] = pTurno;
            }
            else
            {
                lblMsgAlert.Text = "<strong>No existen turnos disponibles en el horario actual, no se cargaran los grupos!</strong>";
                Message.CssClass = String.Format("alert alert-{0} alert-dismissable", Alertas.AlertasType.Danger.ToString().ToLower());
                Message.Attributes.Add("role", "alert");
            }


        }

        #endregion

        private void generaBtnGrupos()
        {

            DataTable dtblTG = new DataTable();
            BOS_TurnoGrupo objTurno = new BOS_TurnoGrupo();
            objTurno.Corporativo = pCorpo;
            objTurno.Central = pCentral;
            objTurno.Turno = pTurno;
            objTurno.FechaProceso = pHoraInicio.ToString("yyyy-MM-dd");
            dtblTG = objTurno.mgetConsultaTurnosGrupos();
            if (dtblTG.Rows.Count > 0)
            {
                for (int i = 0; i <= dtblTG.Rows.Count - 1; i++)
                {

                    Button btnGpo = new Button();
                    btnGpo.Text = dtblTG.Rows[i]["NombreGrupo"].ToString();
                    btnGpo.ID = "G" + dtblTG.Rows[i]["Grupo"].ToString();
                    btnGpo.Font.Bold = true;
                    //btnGpo.ForeColor = System.Drawing.Color.White;
                    //btnGpo.BackColor = System.Drawing.Color.LightSteelBlue;
                    btnGpo.Font.Size = 8;
                    btnGpo.CssClass = "btn btn-primary";
                    btnGpo.Width = Unit.Pixel(210);
                    btnGpo.Height = Unit.Pixel(40);
                    pnlGpo.Controls.Add(btnGpo);
                    pnlGpo.Visible = true;

                    if (i % 2 != 0)
                    {

                        pnlGpo.Controls.Add(new LiteralControl("<div class=\"clearfix\"></div></br>"));


                    }
                    else { pnlGpo.Controls.Add(new LiteralControl("&nbsp;&nbsp;&nbsp;")); }

                    btnGpo.Click += new EventHandler(btnGpo_Click);

                }

                frmGrupo = "Platillos";


            }


        }

        void btnGpo_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            int longitud = btn.ID.Length;
            int gpo = int.Parse(btn.ID.ToString().Substring(1, longitud - 1));
            Session["sClickGrupo"] = gpo;
            Session["sNombregrupo"] = btn.Text;
            generaBtnPlatillosGrupo();
            Session["sPanelAct"] = "divPGrupo";
            cambiaPanel();
        }

        private void generaBtnPlatillos()
        {

            DataTable dtblTP = new DataTable();
            BOS_TurnoPlatillo objPlatillo = new BOS_TurnoPlatillo();
            objPlatillo.Corporativo = pCorpo;
            objPlatillo.Central = pCentral;
            objPlatillo.Turno = pTurno;
            objPlatillo.FechaProceso = pHoraInicio.ToString("yyyy-MM-dd");
            dtblTP = objPlatillo.mgetConsultaTurnosPlatillo();
            if (dtblTP.Rows.Count > 0)
            {

                for (int i = 0; i <= dtblTP.Rows.Count - 1; i++)
                {

                    Button btnPla = new Button();
                    btnPla.Text = dtblTP.Rows[i]["NombrePlatillo"].ToString();


                    btnPla.Font.Bold = true;
                    btnPla.ID = "D" + dtblTP.Rows[i]["Platillo"].ToString();
                    //btnPla.ForeColor = System.Drawing.Color.White;
                    //btnPla.BackColor = System.Drawing.Color.LightSteelBlue;
                    btnPla.Font.Size = 8;
                    btnPla.Width = Unit.Pixel(210);
                    btnPla.Height = Unit.Pixel(40);
                    btnPla.CssClass = "btn btn-success";
                    pnlPla.Controls.Add(btnPla);
                    pnlPla.Visible = true;
                    if (i % 2 != 0)
                    {
                        pnlPla.Controls.Add(new LiteralControl("<div class=\"clearfix\"></div></br>"));
                    }
                    else { pnlPla.Controls.Add(new LiteralControl("&nbsp;&nbsp;&nbsp;")); }
                    btnPla.Click += new EventHandler(btnPla_Click);

                }
            }



        }

        //****************************************************
        // ** Agrega a la lista un platillo para procesarlo**
        //****************************************************

        private void generaPlatillo(int pPlatillo)
        {
            iniciaVariablesPlatillo();

            DataTable dtable = new DataTable();
            BOS_Platillo objPla = new BOS_Platillo();
            bool paquete = false;

            objPla.Corporativo = pCorpo;
            objPla.Central = pCentral;
            objPla.Grupo = 0;
            objPla.Platillo = pPlatillo;
            dtable = objPla.mgetConsultaPlatillosGrupo();
            if (dtable.Rows.Count > 0)
            {
                paquete = bool.Parse(dtable.Rows[0]["Paquete"].ToString());
                if (paquete == true)
                {
                    DataTable dtblPaq = new DataTable();
                    BOS_Paquete objPaq = new BOS_Paquete();
                    objPaq.Corporativo = pCorpo;
                    objPaq.Central = pCentral;
                    objPaq.Platillo = pPlatillo;
                    dtblPaq = objPaq.mgetConsultaPaquete();
                    if (dtblPaq.Rows.Count > 0)
                    {

                        for (int i = 0; i <= dtblPaq.Rows.Count -1; i++)
                        {

                            BOS_PlatilloOrden platilloNuevo = new BOS_PlatilloOrden();
                            platilloNuevo.Id = i;
                            platilloNuevo.Platillo = int.Parse(dtblPaq.Rows[i]["Platillo"].ToString());
                            platilloNuevo.Linea_Paquete = pPlatillo;
                            platilloNuevo.Grupo = int.Parse(dtblPaq.Rows[i]["Grupo"].ToString());
                            platilloNuevo.Clasificacion = dtblPaq.Rows[i]["Clasificacion"].ToString();
                            platilloNuevo.Modificador = bool.Parse(dtblPaq.Rows[i]["Modificador"].ToString());
                            platilloNuevo.Modificador_Cantidad = int.Parse(dtblPaq.Rows[i]["ModificadorCantidad"].ToString());
                            platilloNuevo.Terminador = bool.Parse(dtblPaq.Rows[i]["Terminador"].ToString());
                            platilloNuevo.Precio = decimal.Parse(dtblPaq.Rows[i]["Precio"].ToString());
                            platilloNuevo.Paquete = bool.Parse(dtblPaq.Rows[i]["Paquete"].ToString());
                            platilloNuevo.Promocion = bool.Parse(dtblPaq.Rows[i]["Promocion"].ToString());
                            platilloNuevo.Equivalencia = int.Parse(dtblPaq.Rows[i]["Equivalencia"].ToString());
                            listaPlatillos.Add(platilloNuevo);

                        }

                    }


                }
                else
                {
                    BOS_PlatilloOrden platilloNuevo = new BOS_PlatilloOrden();
                    platilloNuevo.Id = 0;
                    platilloNuevo.Platillo = int.Parse(dtable.Rows[0]["Platillo"].ToString());
                    platilloNuevo.Grupo = int.Parse(dtable.Rows[0]["Grupo"].ToString());
                    platilloNuevo.Clasificacion = dtable.Rows[0]["Clasificacion"].ToString();
                    platilloNuevo.Modificador = bool.Parse(dtable.Rows[0]["Modificador"].ToString());
                    platilloNuevo.Modificador_Cantidad = int.Parse(dtable.Rows[0]["ModificadorCantidad"].ToString());
                    platilloNuevo.Terminador = bool.Parse(dtable.Rows[0]["Terminador"].ToString());
                    platilloNuevo.Precio = decimal.Parse(dtable.Rows[0]["Precio"].ToString());
                    platilloNuevo.Paquete = bool.Parse(dtable.Rows[0]["Paquete"].ToString());
                    platilloNuevo.Promocion = bool.Parse(dtable.Rows[0]["Promocion"].ToString());
                    platilloNuevo.Equivalencia = int.Parse(dtable.Rows[0]["Equivalencia"].ToString());
                    //platilloNuevo.Procesado = true;
                    listaPlatillos.Add(platilloNuevo);
                }



            }

            Session["sContadorProceso"] = null;
            procesaPlatillo(1);
            Session["sProcesaPromocion"] = null;

        }

        //****************************************
        //*** click boton platillo directo 
        //****************************************
        void btnPla_Click(object sender, EventArgs e)
        {
            iniciaVariablesPlatillo();

            DataTable dtable = new DataTable();
            BOS_Platillo objPla = new BOS_Platillo();
            Button btn = sender as Button;
            int longitud = btn.ID.Length;
            int pPlatillo = int.Parse(btn.ID.ToString().Substring(1, longitud - 1));          
            bool paquete = false;


            objPla.Corporativo = pCorpo;
            objPla.Central = pCentral;
            objPla.Grupo = 0;
            objPla.Platillo = pPlatillo;
            dtable = objPla.mgetConsultaPlatillosGrupo();
            if (dtable.Rows.Count > 0)
            {
                paquete = bool.Parse(dtable.Rows[0]["Paquete"].ToString());
                if (paquete == true)
                {
                    DataTable dtblPaq = new DataTable();
                    BOS_Paquete objPaq = new BOS_Paquete();
                    objPaq.Corporativo = pCorpo;
                    objPaq.Central = pCentral;
                    objPaq.Platillo = pPlatillo;
                    dtblPaq = objPaq.mgetConsultaPaquete();
                    if (dtblPaq.Rows.Count > 0)
                    {

                        for (int i = 0; i < dtblPaq.Rows.Count ; i++)
                        {

                            BOS_PlatilloOrden platilloNuevo = new BOS_PlatilloOrden();
                            platilloNuevo.Id = i;
                            platilloNuevo.Platillo = int.Parse(dtblPaq.Rows[i]["Platillo"].ToString());
                            platilloNuevo.Linea_Paquete = pPlatillo;
                            platilloNuevo.Grupo = int.Parse(dtblPaq.Rows[i]["Grupo"].ToString());
                            platilloNuevo.Clasificacion = dtblPaq.Rows[i]["Clasificacion"].ToString();
                            platilloNuevo.Modificador = bool.Parse(dtblPaq.Rows[i]["Modificador"].ToString());
                            platilloNuevo.Modificador_Cantidad = int.Parse(dtblPaq.Rows[i]["ModificadorCantidad"].ToString());
                            platilloNuevo.Terminador = bool.Parse(dtblPaq.Rows[i]["Terminador"].ToString());
                            platilloNuevo.Precio = decimal.Parse(dtblPaq.Rows[i]["Precio"].ToString());
                            platilloNuevo.Paquete = bool.Parse(dtblPaq.Rows[i]["Paquete"].ToString());
                            platilloNuevo.Promocion = bool.Parse(dtblPaq.Rows[i]["Promocion"].ToString());
                            platilloNuevo.Equivalencia = int.Parse(dtblPaq.Rows[i]["Equivalencia"].ToString());
                            listaPlatillos.Add(platilloNuevo);

                        }

                    }


                }
                else
                {
                    BOS_PlatilloOrden platilloNuevo = new BOS_PlatilloOrden();
                    platilloNuevo.Id = 0;
                    platilloNuevo.Platillo = int.Parse(dtable.Rows[0]["Platillo"].ToString());
                    platilloNuevo.Grupo = int.Parse(dtable.Rows[0]["Grupo"].ToString());
                    platilloNuevo.Clasificacion = dtable.Rows[0]["Clasificacion"].ToString();
                    platilloNuevo.Modificador = bool.Parse(dtable.Rows[0]["Modificador"].ToString());
                    platilloNuevo.Modificador_Cantidad = int.Parse(dtable.Rows[0]["ModificadorCantidad"].ToString());
                    platilloNuevo.Terminador = bool.Parse(dtable.Rows[0]["Terminador"].ToString());
                    platilloNuevo.Precio = decimal.Parse(dtable.Rows[0]["Precio"].ToString());
                    platilloNuevo.Paquete = bool.Parse(dtable.Rows[0]["Paquete"].ToString());
                    platilloNuevo.Promocion = bool.Parse(dtable.Rows[0]["Promocion"].ToString());
                    platilloNuevo.Equivalencia = int.Parse(dtable.Rows[0]["Equivalencia"].ToString());
                    //platilloNuevo.Procesado = true;
                    listaPlatillos.Add(platilloNuevo);
                }



            }

            Session["sContadorProceso"] = null;
            procesaPlatillo(1);
            Session["sProcesaPromocion"] = null;

        }

        private void generaBtnPlatillosGrupo()
        {
            pnlPlatilloGpo.Controls.Clear();

            DataTable dtblPG = new DataTable();
            BOS_Platillo objPla = new BOS_Platillo();
            int gpo = int.Parse(Session["sClickGrupo"].ToString());
            frmGrupo = Session["sNombregrupo"].ToString();
            objPla.Corporativo = pCorpo;
            objPla.Central = pCentral;
            objPla.Grupo = gpo;
            objPla.Platillo = 0;
            dtblPG = objPla.mgetConsultaPlatillosGrupo();
            if (dtblPG.Rows.Count > 0)
            {
                for (int i = 0; i <= dtblPG.Rows.Count - 1; i++)
                {

                    Button btnPlaGpo = new Button();
                    btnPlaGpo.Text = dtblPG.Rows[i]["NombrePlatillo"].ToString();
                    btnPlaGpo.Font.Bold = true;
                    btnPlaGpo.ID = "T" + dtblPG.Rows[i]["Platillo"].ToString();
                    //btnPla.ForeColor = System.Drawing.Color.White;
                    //btnPla.BackColor = System.Drawing.Color.LightSteelBlue;
                    btnPlaGpo.Font.Size = 8;
                    btnPlaGpo.Width = Unit.Pixel(210);
                    btnPlaGpo.Height = Unit.Pixel(40);
                    btnPlaGpo.CssClass = "btn btn-info";
                    pnlPlatilloGpo.Controls.Add(btnPlaGpo);
                    pnlPlatilloGpo.Visible = true;
                    if (i % 2 != 0)
                    {
                        pnlPlatilloGpo.Controls.Add(new LiteralControl("<div class=\"clearfix\"></div></br>"));
                    }
                    else { pnlPlatilloGpo.Controls.Add(new LiteralControl("&nbsp;&nbsp;&nbsp;")); }
                    btnPlaGpo.Click += new EventHandler(btnPlaGpo_Click);

                }
            }
        }

        //************************************************
        //***  click boton de platillo de un grupo  *****
        //************************************************
        void btnPlaGpo_Click(object sender, EventArgs e)
        {

            iniciaVariablesPlatillo();

            DataTable dtable = new DataTable();
            BOS_Platillo objPla = new BOS_Platillo();
            Button btn = sender as Button;
            int longitud = btn.ID.Length;
            int pPlatillo = int.Parse(btn.ID.ToString().Substring(1, longitud - 1));
            bool paquete = false;


            objPla.Corporativo = pCorpo;
            objPla.Central = pCentral;
            objPla.Grupo = 0;
            objPla.Platillo = pPlatillo;
            dtable = objPla.mgetConsultaPlatillosGrupo();
            if (dtable.Rows.Count > 0)
            {

                paquete = bool.Parse(dtable.Rows[0]["Paquete"].ToString());
                if (paquete == true)
                {
                    DataTable dtblPaq = new DataTable();
                    BOS_Paquete objPaq = new BOS_Paquete();
                    objPaq.Corporativo = pCorpo;
                    objPaq.Central = pCentral;
                    objPaq.Platillo = pPlatillo;
                    dtblPaq = objPaq.mgetConsultaPaquete();
                    if (dtblPaq.Rows.Count > 0)
                    {


                        for (int i = 0; i < dtblPaq.Rows.Count ; i++)
                        {
                            BOS_PlatilloOrden platilloNuevo = new BOS_PlatilloOrden();
                            platilloNuevo.Id = i;
                            platilloNuevo.Platillo = int.Parse(dtblPaq.Rows[i]["Platillo"].ToString());
                            platilloNuevo.Linea_Paquete = pPlatillo;
                            platilloNuevo.Grupo = int.Parse(dtblPaq.Rows[i]["Grupo"].ToString());
                            platilloNuevo.Clasificacion = dtblPaq.Rows[i]["Clasificacion"].ToString();
                            platilloNuevo.Modificador = bool.Parse(dtblPaq.Rows[i]["Modificador"].ToString());
                            platilloNuevo.Modificador_Cantidad = int.Parse(dtblPaq.Rows[i]["ModificadorCantidad"].ToString());
                            platilloNuevo.Terminador = bool.Parse(dtblPaq.Rows[i]["Terminador"].ToString());
                            platilloNuevo.Precio = decimal.Parse(dtblPaq.Rows[i]["Precio"].ToString());
                            platilloNuevo.Paquete = bool.Parse(dtblPaq.Rows[i]["Paquete"].ToString());
                            platilloNuevo.Promocion = bool.Parse(dtblPaq.Rows[i]["Promocion"].ToString());
                            platilloNuevo.Equivalencia = int.Parse(dtblPaq.Rows[i]["Equivalencia"].ToString());
                            listaPlatillos.Add(platilloNuevo);

                        }
                    }


                }
                else
                {
                    BOS_PlatilloOrden platilloNuevo = new BOS_PlatilloOrden();
                    platilloNuevo.Id = 0;
                    platilloNuevo.Platillo = int.Parse(dtable.Rows[0]["Platillo"].ToString());
                    platilloNuevo.Grupo = int.Parse(dtable.Rows[0]["Grupo"].ToString());
                    platilloNuevo.Clasificacion = dtable.Rows[0]["Clasificacion"].ToString();
                    platilloNuevo.Modificador = bool.Parse(dtable.Rows[0]["Modificador"].ToString());
                    platilloNuevo.Modificador_Cantidad = int.Parse(dtable.Rows[0]["ModificadorCantidad"].ToString());
                    platilloNuevo.Terminador = bool.Parse(dtable.Rows[0]["Terminador"].ToString());
                    platilloNuevo.Precio = decimal.Parse(dtable.Rows[0]["Precio"].ToString());
                    platilloNuevo.Paquete = bool.Parse(dtable.Rows[0]["Paquete"].ToString());
                    platilloNuevo.Promocion = bool.Parse(dtable.Rows[0]["Promocion"].ToString());
                    platilloNuevo.Equivalencia = int.Parse(dtable.Rows[0]["Equivalencia"].ToString());
                    //platilloNuevo.Procesado = true;
                    listaPlatillos.Add(platilloNuevo);
                }


            }

            Session["sContadorProceso"] = null;
            procesaPlatillo(1);
            Session["sProcesaPromocion"] = null;

        }


        private void agregaOrden()
        {
            string format = "yyyy-MM-dd HH:mm:ss";

            var objOrden = new BOS_Orden()
            {
                Corporativo = pCorpo,
                Central = pCentral,
                Orden = 1,
                Sucursal = pSucursal,
                Id_Cliente = pIdCliente,
                Id_Direccion = pIdDireccion,
                Comensales = 1,
                Turno = pTurno,
                Nota = "",
                Origen = pOrigen,
                Forma_Pago = "",
                Fecha_Captura_Inicio = pHoraInicio.ToString(format),
                Operador_Captura = pOperador,
                Fecha_Captura_Fin = "",
                Promesa_Entrega = "",
                Estatus = "",
                Repartidor = 0,
                Usuario_Cancela = "",
                Fecha_Cancela = "",
                Nota_Cancela = "",
                RFC = "",
                Codigo_Postal = "",
                Fecha_Procesar = ""

            };

            listaOrden.Add(objOrden);
            Session["slistOrden"] = objOrden;

        }

        private void actualizaOrden()
        {
            string format = "yyyy-MM-dd HH:mm:ss";
            var orden = listaOrden.Where(x => x.Orden == 1).FirstOrDefault();


            pFormaPago = HttpContext.Current.Session["sFormaPago"].ToString();
            DateTime fechaPromesa = DateTime.Now.AddHours(1);

            if (cbxFuturo.Checked == false)
            {
                BOS_Central objPPE = new BOS_Central();
                objPPE.Corporativo = pCorpo;
                objPPE.Central = pCentral;
                objPPE.Comensales = int.Parse(txtTotCom.Text);
                pFechaProcesar = DateTime.Now.AddHours(1);
                pFechaPromesa = pFechaProcesar.AddMinutes(int.Parse(objPPE.mgetParametrosPromesaEntrega().Rows[0]["Minutos"].ToString()));
                pFechaFin = DateTime.Now.AddHours(1);
            }
            else
            {
                if (HttpContext.Current.Session["sFechaPromesa"] != null)
                    fechaPromesa = DateTime.Parse(HttpContext.Current.Session["sFechaPromesa"].ToString());

                BOS_Central objPPE = new BOS_Central();
                objPPE.Corporativo = pCorpo;
                objPPE.Central = pCentral;
                pFechaPromesa = fechaPromesa;
                pFechaProcesar = fechaPromesa.AddMinutes(-int.Parse(objPPE.mgetConsultaCentral().Rows[0]["MinutosProcesaOrdenFuturo"].ToString()));
                pFechaFin = DateTime.Now.AddHours(1);
            }

            orden.Promesa_Entrega = pFechaPromesa.ToString(format);
            orden.Fecha_Procesar = pFechaProcesar.ToString(format);
            orden.Comensales = int.Parse(txtTotCom.Text);
            orden.Fecha_Captura_Fin = pFechaFin.ToString(format);


            if (HttpContext.Current.Session["sFormaPago"] != null)
                orden.Forma_Pago = HttpContext.Current.Session["sFormaPago"].ToString();

        }


        private void agregaOrdenDetalle(int pPlatillo, int pLineaPaquete, bool pNoPregunta)
        {
            DataTable dtable = new DataTable();
            BOS_OrdenDetalle ordenNueva = new BOS_OrdenDetalle();
            BOS_Platillo objPla = new BOS_Platillo();


            if (HttpContext.Current.Session["sLineaOrden"] != null)
            {
                lineaOrden = int.Parse(Session["sLineaOrden"].ToString());
                lineaOrden++;
            }
            else
            {
                lineaOrden = 1;
            }

            ordenNueva.Corporativo = pCorpo;
            ordenNueva.Central = pCentral;
            ordenNueva.Linea = lineaOrden;
            ordenNueva.NoPregunta = pNoPregunta;

            decimal iva = (decimal)1 + (decimal).16;
           

            if (HttpContext.Current.Session["Equivalencia"] != null)
            {
                objPla.Corporativo = pCorpo;
                objPla.Central = pCentral;
                objPla.Grupo = 0;
                objPla.Platillo = int.Parse(HttpContext.Current.Session["Equivalencia"].ToString());
                dtable = objPla.mgetConsultaPlatillosGrupo();
                if (dtable.Rows.Count > 0)
                {
                    ordenNueva.Platillo = int.Parse(dtable.Rows[0]["Platillo"].ToString());
                    ordenNueva.Nombre_Platillo = dtable.Rows[0]["NombrePlatillo"].ToString();
                    ordenNueva.Clasificacion = dtable.Rows[0]["Clasificacion"].ToString();
                    if (HttpContext.Current.Session["sLineaPaquete"] == null)
                    {
                        ordenNueva.Precio = decimal.Round(decimal.Parse(dtable.Rows[0]["Precio"].ToString()),4);
                        ordenNueva.Precio_Neto =decimal.Round(( decimal.Parse(dtable.Rows[0]["Precio"].ToString()) / iva), 4) * 1;
                        lineaPrecio = decimal.Parse(dtable.Rows[0]["Precio"].ToString());
                    }
                }
            }
 
            objPla.Corporativo = pCorpo;
            objPla.Central = pCentral;
            objPla.Grupo = 0;
            objPla.Platillo = pPlatillo;
            dtable = objPla.mgetConsultaPlatillosGrupo();
            if (dtable.Rows.Count > 0)
            {
                if (HttpContext.Current.Session["Equivalencia"] == null)
                {
                    ordenNueva.Platillo = int.Parse(dtable.Rows[0]["Platillo"].ToString());
                    ordenNueva.Nombre_Platillo = dtable.Rows[0]["NombrePlatillo"].ToString();
                    ordenNueva.Clasificacion = dtable.Rows[0]["Clasificacion"].ToString();
                    ordenNueva.Precio = decimal.Round(decimal.Parse(dtable.Rows[0]["Precio"].ToString()), 4);
                    ordenNueva.Precio_Neto = decimal.Round((decimal.Parse(dtable.Rows[0]["Precio"].ToString()) / iva), 4) * 1;
                    lineaPrecio = decimal.Parse(dtable.Rows[0]["Precio"].ToString());

                }


                if (HttpContext.Current.Session["sPrecioPromocion"] != null)
                {
                    ordenNueva.Precio = decimal.Round(decimal.Parse(HttpContext.Current.Session["sPrecioPromocion"].ToString()),4);
                    ordenNueva.Precio_Neto = decimal.Round((decimal.Parse(HttpContext.Current.Session["sPrecioPromocion"].ToString()) / iva), 4) * int.Parse(HttpContext.Current.Session["sCantidadPromocion"].ToString());
                    ordenNueva.Cantidad = int.Parse(HttpContext.Current.Session["sCantidadPromocion"].ToString());
                    ordenNueva.Linea_Promocion = lineaOrden;
                    lineaPrecio = decimal.Parse(HttpContext.Current.Session["sPrecioPromocion"].ToString()) * int.Parse(HttpContext.Current.Session["sCantidadPromocion"].ToString());

                    //inserta si es promocion
                    if (HttpContext.Current.Session["sLineaPromocion"] != null)
                    {
                        ordenNueva.Linea_Promocion = int.Parse(HttpContext.Current.Session["sLineaPromocion"].ToString());
                    }

                }
                else
                {
                    // inserta si es promocion
                    if (bool.Parse(dtable.Rows[0]["Promocion"].ToString()) == true && bool.Parse(dtable.Rows[0]["Paquete"].ToString()) == false && decimal.Parse(dtable.Rows[0]["Precio"].ToString()) > 0)
                    {
                        ordenNueva.Linea_Promocion = lineaOrden;
                        Session["sLineaPromocion"] = lineaOrden;
                    }
                    ordenNueva.Cantidad = 1;
                }



            }


            ordenNueva.Nota_Platillo = "";
            if (HttpContext.Current.Session["Terminador"] != null)
            {
                string descTerm = "";
                descTerm = HttpContext.Current.Session["TerminadorNombre"].ToString();
                ordenNueva.Desc_Terminador = " T/" + descTerm;
                ordenNueva.TermVisible = true;

            }
            else
            {
                ordenNueva.Desc_Terminador = "";
                ordenNueva.TermVisible = false;
            }

            if (HttpContext.Current.Session["Modificador"] != null)
            {
                string descMod = "";
                descMod = HttpContext.Current.Session["ModificadorNombre"].ToString();
                ordenNueva.Desc_Modificador = " M/" + descMod;
                ordenNueva.ModVisible = true;

            }
            else
            {
                ordenNueva.Desc_Modificador = "";
                ordenNueva.ModVisible = false;
            }

            string format = "yyyy-MM-dd HH:mm:ss";

            ordenNueva.Comensal = int.Parse(txtCom.Text);
            ordenNueva.Servicio = 0;
            ordenNueva.Descuento = 0;
            ordenNueva.Descuento_Porcentaje = 0;
            ordenNueva.Fecha_Captura_Platillo = DateTime.Now.AddHours(1).ToString(format);
            ordenNueva.Activo = true;
            ordenNueva.Usuario_Cancela = "";
            ordenNueva.Fecha_Cancela = "";
            ordenNueva.Nota_Cancela = "";
            if (pLineaPaquete > 0)
            {
                if (HttpContext.Current.Session["sLineaPaquete"] != null)
                {
                    ordenNueva.Linea_Paquete = int.Parse(HttpContext.Current.Session["sLineaPaquete"].ToString());
                }
                else
                {
                    Session["sLineaPaquete"] = lineaOrden;
                    ordenNueva.Linea_Paquete = lineaOrden;
                }



            }
            else
            {
                Session["sLineaPaquete"] = null;
            }


            if (ordenNueva.Precio > 0)
            {
                ordenNueva.Botones = true;

                if (HttpContext.Current.Session["sPromoPreguntando"] != null)
                {
                    if (bool.Parse(HttpContext.Current.Session["sPromoPreguntando"].ToString()) == true)
                        ordenNueva.Botones = false;
                }

                if (pLineaPaquete != pPlatillo)
                {
                    if (pLineaPaquete > 0 && ordenNueva.Precio > 0)
                        ordenNueva.Botones = false;
                }
            }
            else { ordenNueva.Botones = false; }


            listaOrdenDetalle.Add(ordenNueva);
            Session["sLineaOrden"] = lineaOrden;
            sumaTotales(lineaPrecio);
        }




        private void sumaTotales(decimal Precio)
        {
            decimal subTotal = 0;
            decimal sumaTot = 0;
            decimal iva = 0;
            decimal ivaTotal = 0;

            int totpla = 0;

            //if (HttpContext.Current.Session["sTotal"] != null)
            //    sumaTot = decimal.Parse(HttpContext.Current.Session["sTotal"].ToString());
            //sumaTot = decimal.Round(sumaTot + Precio, 2);
            //Session["sTotal"] = sumaTot;
            var lista = listaOrdenDetalle.ToList();
            foreach (var item in lista)
            {
                sumaTot = sumaTot + ( (decimal)item.Precio * (decimal)item.Cantidad);
            }     
           
            frmTotal = string.Format("{0:0.00}", sumaTot);

            //if (HttpContext.Current.Session["sTotPla"] != null)
            //    totpla = int.Parse(HttpContext.Current.Session["sTotPla"].ToString());
            //totpla++;
            //Session["sTotPla"] = totpla;
            var sumListPla = listaOrdenDetalle.Sum(x => x.Cantidad);
            totpla = (int)sumListPla;
            frmTotPla = totpla.ToString();

            //Totales
            iva = (decimal)1 + (decimal).16;
            subTotal = decimal.Round((sumaTot / iva), 2);
            ivaTotal = decimal.Round(sumaTot - subTotal, 2);

            frmSubTot = string.Format("{0:0.00}", subTotal);
            frmIVA = string.Format("{0:0.00}", ivaTotal);
            frmDesc = "0";
        }

        private void restaTotales(decimal Precio)
        {
            decimal subTotal = 0;
            decimal sumaTot = 0;
            decimal iva = 0;
            decimal ivaTotal = 0;
            int totpla = 0;

            //if (HttpContext.Current.Session["sTotal"] != null)
            //    sumaTot = decimal.Parse(HttpContext.Current.Session["sTotal"].ToString());
            //sumaTot = decimal.Round(sumaTot - Precio, 2);
            //Session["sTotal"] = sumaTot;
            var lista = listaOrdenDetalle.ToList();
            foreach (var item in lista)
            {
                sumaTot = sumaTot + ((decimal)item.Precio * (decimal)item.Cantidad);
            }
            frmTotal = string.Format("{0:0.00}", sumaTot);

            //if (HttpContext.Current.Session["sTotPla"] != null)
            //    totpla = int.Parse(HttpContext.Current.Session["sTotPla"].ToString());
            //totpla--;
            //Session["sTotPla"] = totpla;
            var sumListPla = listaOrdenDetalle.Sum( x => x.Cantidad);
            totpla = (int)sumListPla;
            frmTotPla = totpla.ToString();

            //Totales
            iva = (decimal)1 + (decimal).16;
            subTotal = decimal.Round((sumaTot / iva), 2);
            ivaTotal = decimal.Round(sumaTot - subTotal, 2);

            frmSubTot = string.Format("{0:0.00}", subTotal);
            frmIVA = string.Format("{0:0.00}", ivaTotal);
            frmDesc = "0";

        }

        private void refreshTotales()
        {
            decimal subTotal = 0;
            decimal sumaTot = 0;
            decimal iva = 0;
            decimal ivaTotal = 0;
            int totpla = 0;
            
            var lista = listaOrdenDetalle.ToList();
            foreach (var item in lista)
            {
                sumaTot = sumaTot + ((decimal)item.Precio * (decimal)item.Cantidad);
            }
            frmTotal = string.Format("{0:##0.N2}", sumaTot);

          
            var sumListPla = listaOrdenDetalle.Sum(x => x.Cantidad);
            totpla = (int)sumListPla;
            frmTotPla = totpla.ToString();

            //Totales            
            iva = (decimal)1 + (decimal).16;
            subTotal = decimal.Round((sumaTot / iva), 2);
            ivaTotal = decimal.Round(sumaTot - subTotal, 2);
            sumaTot = decimal.Round(sumaTot, 2);

            frmTotal = string.Format("{0:##0.N2}", sumaTot);
            frmSubTot = string.Format("{0:##0.N2}", subTotal);
            frmIVA = string.Format("{0:##0.N2}", ivaTotal);            
            frmDesc = "0";

        }

        private void refreshGrdOrden()
        {
            grdCaptura.DataSource = listaOrdenDetalle;
            grdCaptura.DataBind();
            HttpContext.Current.Session["Equivalencia"] = null;
            HttpContext.Current.Session["Terminador"] = null;
            HttpContext.Current.Session["TerminadorNombre"] = null;
            HttpContext.Current.Session["Modificador"] = null;
            HttpContext.Current.Session["ModificadorNombre"] = null;
            HttpContext.Current.Session["sPrecioPromocion"] = null;
            HttpContext.Current.Session["sCantidadPromocion"] = null;

            procesaPlatillo(1);

        }

        private void refreshGrdOrdenPromo()
        {
            grdCaptura.DataSource = listaOrdenDetalle;
            grdCaptura.DataBind();
            HttpContext.Current.Session["Equivalencia"] = null;
            HttpContext.Current.Session["Terminador"] = null;
            HttpContext.Current.Session["TerminadorNombre"] = null;
            HttpContext.Current.Session["Modificador"] = null;
            HttpContext.Current.Session["ModificadorNombre"] = null;
            HttpContext.Current.Session["sPrecioPromocion"] = null;
            HttpContext.Current.Session["sCantidadPromocion"] = null;


        }

        protected void btnOrden_Click(object sender, EventArgs e)
        {
            //Click Boton enviar orden -->> datos Fiscales
            var linea = listaOrdenDetalle.Count();
            if (linea > 0)
            {
                if (HttpContext.Current.Session["sFormaPago"] != null)
                {
                    actualizaOrden();
                    Response.Redirect("DatosFiscales.aspx?Corpo=" + pCorpo.ToString() + "&Central=" + pCentral + "&Ori=" + pOrigen + "&Oper=" + pOperador + "&Tel=" + pTelefono + "&Suc=" + pSucursal + " &IdCli=" + pIdCliente.ToString() + "&IdDir=" + pIdDireccion.ToString() + "&HoraI=" + pHoraInicio.ToString("hh:mm:ss tt") + "&Orden=" + pOrden.ToString());

                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Bluekey Message", "alert('Seleccione una forma de pago valida!')", true);
                }
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Bluekey Message", "alert('No se capturaron platillos, no se puede enviar pedido vacío!')", true);
            }


           

           
            //if (HttpContext.Current.Session["sRFC"] != null)
            //{ pRFC = HttpContext.Current.Session["sRFC"].ToString(); }
            //else { pRFC = ""; }

            //if (pRFC == "")
            //{
            //    lblMsgAlert.Text = "<strong>Debe seleccionar un RFC!</strong>";
            //    Message.CssClass = String.Format("alert alert-{0} alert-dismissable", Alertas.AlertasType.Danger.ToString().ToLower());
            //    Message.Attributes.Add("role", "alert");
            //}
            //else
            //{
            //    Response.Redirect("Orden.aspx?Corpo=" + pCorpo.ToString() + "&Central=" + pCentral + " &Oper=" + pOperador + "&Suc=" + pSucursal + " &IdCli=" + pIdCliente.ToString() + "&IdDir=" + pIdDireccion.ToString() + "&HoraI=" + pHoraInicio.ToString("hh:mm:ss tt") + "&rfc=" + pRFC);
            //}

        }


        protected void btnBuscar_Click(object sender, ImageClickEventArgs e)
        {
            if (HttpContext.Current.Session["sClickBusqueda"] != null)
            {
                pnlBusqueda.Controls.Clear();
            }

            Session["sBusqueda"] = null;
            if (txtBusqueda.Text != "")
            {
                // validar que la busqueda sea diferente o hacer algo
                generaBtnPlatilloBusqueda();

                if (bool.Parse(HttpContext.Current.Session["sBusqueda"].ToString()) == false)
                {
                    //frmBusqueda = "No se encontraron coincidencias con su busqueda <strong>" + txtBusqueda.Text + "</strong>";
                    Session["sClickBusqueda"] = null;
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Bluekey Message", "alert('No se encontraron platillos con la descripcion " + txtBusqueda.Text + "')", true);
                    txtBusqueda.Text = "";
                    Session["sPanelAct"] = "divGpo";
                    cambiaPanel();

                }
                else
                {

                    Session["sClickBusqueda"] = true;
                    Session["sPanelAct"] = "divBusqueda";
                    cambiaPanel();
                }
            }
            else
            {

                Session["sClickBusqueda"] = null;
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Bluekey Message", "alert('No se encontraron platillos con la descripcion " + txtBusqueda.Text + "')", true);
                txtBusqueda.Text = "";
                Session["sPanelAct"] = "divGpo";
                cambiaPanel();
                //lblMsgAlert.Text = "<strong>Capture un platillo a buscar!</strong>";
                //Message.CssClass = String.Format("alert alert-{0} alert-dismissable", Alertas.AlertasType.Danger.ToString().ToLower());
                //Message.Attributes.Add("role", "alert");
            }
        }               


        private void generaBtnPlatilloBusqueda()
        {
            DataTable dtblPG = new DataTable();
            BOS_Platillo objPla = new BOS_Platillo();

            objPla.Corporativo = pCorpo;
            objPla.Central = pCentral;
            objPla.Turno = pTurno;
            objPla.Nombre_Platillo = txtBusqueda.Text;
            objPla.FechaProceso = pHoraInicio.ToString("yyyy-MM-dd");
            dtblPG = objPla.mgetConsultaPlatillosNombre();
            if (dtblPG.Rows.Count > 0)
            {

                for (int i = 0; i <= dtblPG.Rows.Count - 1; i++)
                {
                    Button btnBusqueda = new Button();
                    btnBusqueda.Text = dtblPG.Rows[i]["NombrePlatillo"].ToString();


                    btnBusqueda.Font.Bold = true;
                    btnBusqueda.ID = "B" + dtblPG.Rows[i]["Platillo"].ToString();
                    //btnPla.ForeColor = System.Drawing.Color.White;
                    //btnPla.BackColor = System.Drawing.Color.LightSteelBlue;
                    btnBusqueda.Font.Size = 8;
                    btnBusqueda.Width = Unit.Pixel(210);
                    btnBusqueda.Height = Unit.Pixel(40);
                    btnBusqueda.CssClass = "btn btn-warning";
                    pnlBusqueda.Controls.Add(btnBusqueda);
                    pnlBusqueda.Visible = true;
                    if (i % 2 != 0)
                    {
                        pnlBusqueda.Controls.Add(new LiteralControl("<div class=\"clearfix\"></div></br>"));
                    }
                    else { pnlBusqueda.Controls.Add(new LiteralControl("&nbsp;&nbsp;&nbsp;")); }
                    btnBusqueda.Click += new EventHandler(btnBusqueda_Click);
                }

                Session["sBusqueda"] = true;
            }
            else
            {
                Session["sBusqueda"] = false;
            }
        }

        //******************************************************
        //***  Click boton de platillo desde la  busqueda  ****
        //******************************************************
        void btnBusqueda_Click(object sender, EventArgs e)
        {
            iniciaVariablesPlatillo();

            DataTable dtable = new DataTable();
            BOS_Platillo objPla = new BOS_Platillo();
            Button btn = sender as Button;
            int longitud = btn.ID.Length;
            int pPlatillo = int.Parse(btn.ID.ToString().Substring(1, longitud - 1));
            bool paquete = false;

            objPla.Corporativo = pCorpo;
            objPla.Central = pCentral;
            objPla.Grupo = 0;
            objPla.Platillo = pPlatillo;
            dtable = objPla.mgetConsultaPlatillosGrupo();
            if (dtable.Rows.Count > 0)
            {
                paquete = bool.Parse(dtable.Rows[0]["Paquete"].ToString());
                if (paquete == true)
                {
                    DataTable dtblPaq = new DataTable();
                    BOS_Paquete objPaq = new BOS_Paquete();
                    objPaq.Corporativo = pCorpo;
                    objPaq.Central = pCentral;
                    objPaq.Platillo = pPlatillo;
                    dtblPaq = objPaq.mgetConsultaPaquete();
                    if (dtblPaq.Rows.Count > 0)
                    {


                        for (int i = 0; i < dtblPaq.Rows.Count ; i++)
                        {
                            BOS_PlatilloOrden platilloNuevo = new BOS_PlatilloOrden();
                            platilloNuevo.Id = i;
                            platilloNuevo.Platillo = int.Parse(dtblPaq.Rows[i]["Platillo"].ToString());
                            platilloNuevo.Linea_Paquete = pPlatillo;
                            platilloNuevo.Grupo = int.Parse(dtblPaq.Rows[i]["Grupo"].ToString());
                            platilloNuevo.Clasificacion = dtblPaq.Rows[i]["Clasificacion"].ToString();
                            platilloNuevo.Modificador = bool.Parse(dtblPaq.Rows[i]["Modificador"].ToString());
                            platilloNuevo.Modificador_Cantidad = int.Parse(dtblPaq.Rows[i]["ModificadorCantidad"].ToString());
                            platilloNuevo.Terminador = bool.Parse(dtblPaq.Rows[i]["Terminador"].ToString());
                            platilloNuevo.Precio = decimal.Parse(dtblPaq.Rows[i]["Precio"].ToString());
                            platilloNuevo.Paquete = bool.Parse(dtblPaq.Rows[i]["Paquete"].ToString());
                            platilloNuevo.Promocion = bool.Parse(dtblPaq.Rows[i]["Promocion"].ToString());
                            platilloNuevo.Equivalencia = int.Parse(dtblPaq.Rows[i]["Equivalencia"].ToString());
                            listaPlatillos.Add(platilloNuevo);

                        }

                    }


                }
                else
                {
                    BOS_PlatilloOrden platilloNuevo = new BOS_PlatilloOrden();
                    platilloNuevo.Id = 0;
                    platilloNuevo.Platillo = int.Parse(dtable.Rows[0]["Platillo"].ToString());
                    platilloNuevo.Grupo = int.Parse(dtable.Rows[0]["Grupo"].ToString());
                    platilloNuevo.Clasificacion = dtable.Rows[0]["Clasificacion"].ToString();
                    platilloNuevo.Modificador = bool.Parse(dtable.Rows[0]["Modificador"].ToString());
                    platilloNuevo.Modificador_Cantidad = int.Parse(dtable.Rows[0]["ModificadorCantidad"].ToString());
                    platilloNuevo.Terminador = bool.Parse(dtable.Rows[0]["Terminador"].ToString());
                    platilloNuevo.Precio = decimal.Parse(dtable.Rows[0]["Precio"].ToString());
                    platilloNuevo.Paquete = bool.Parse(dtable.Rows[0]["Paquete"].ToString());
                    platilloNuevo.Promocion = bool.Parse(dtable.Rows[0]["Promocion"].ToString());
                    platilloNuevo.Equivalencia = int.Parse(dtable.Rows[0]["Equivalencia"].ToString());
                    listaPlatillos.Add(platilloNuevo);
                }



            }


            Session["sContadorProceso"] = null;
            procesaPlatillo(1);
            Session["sProcesaPromocion"] = null;


        }

        private void generaPlatilloEquivalencia(int pPlatillo)
        {
            DataTable dtable = new DataTable();
            BOS_PlatilloEquivalencia objEqui = new BOS_PlatilloEquivalencia();
            int estado = 0;
            try
            {
                //1er proceso                
                objEqui.Corporativo = int.Parse(HttpContext.Current.Session["sCorpo"].ToString());
                objEqui.Central = HttpContext.Current.Session["sCentral"].ToString();
                objEqui.Platillo = pPlatillo;
                dtable = objEqui.mgetEquivalenciasPlatillo();
                if (dtable.Rows.Count > 0)
                {
                    pnlBtnEquivalencias.Controls.Clear();

                    for (int i = 0; i <= dtable.Rows.Count - 1; i++)
                    {
                        Button btnEquivalencia = new Button();
                        btnEquivalencia.Text = dtable.Rows[i]["NombrePlatillo"].ToString();


                        btnEquivalencia.Font.Bold = true;
                        btnEquivalencia.ID = "E" + dtable.Rows[i]["PlatilloEquivalente"].ToString();
                        //btnPla.ForeColor = System.Drawing.Color.White;
                        //btnPla.BackColor = System.Drawing.Color.LightSteelBlue;
                        btnEquivalencia.Font.Size = 8;
                        btnEquivalencia.Width = Unit.Pixel(210);
                        btnEquivalencia.Height = Unit.Pixel(40);
                        btnEquivalencia.CssClass = "btn btn-warning";
                        pnlBtnEquivalencias.Controls.Add(btnEquivalencia);
                        pnlBtnEquivalencias.Visible = true;
                        if (i % 2 != 0)
                        {
                            pnlBtnEquivalencias.Controls.Add(new LiteralControl("<div class=\"clearfix\"></div></br>"));
                        }
                        else { pnlBtnEquivalencias.Controls.Add(new LiteralControl("&nbsp;&nbsp;&nbsp;")); }
                        btnEquivalencia.Click += new EventHandler(btnEquivalencia_Click);
                    }

                    Session["sEquivalencia"] = pPlatillo;

                }
                else
                {
                    estado = 2;
                }
            }
            finally
            {
                if (estado == 0)
                    this.modalExtEquivalencias.Show();

                if (estado > 0)
                    procesaPlatillo(2);
            }

        }


        void btnEquivalencia_Click(object sender, EventArgs e)
        {
            DataTable dtable = new DataTable();
            BOS_Platillo objPla = new BOS_Platillo();
            Button btn = sender as Button;
            int longitud = btn.ID.Length;
            int pPlatillo = int.Parse(btn.ID.ToString().Substring(1, longitud - 1));

            try
            {
                Session["Equivalencia"] = pPlatillo; // asigna el platillo equivalente              

            }
            finally
            {
                this.modalExtEquivalencias.Hide();
                procesaPlatillo(2);
            }

        }

        //private void generaPlatilloPaquete(int pPlatillo)
        //{
        //    //Estado: 1           
        //    int equivalencia;
        //    int estado = 0;
        //    DataTable dtable = new DataTable();
        //    BOS_Paquete objPaq = new BOS_Paquete();
        //    objPaq.Corporativo = pCorpo;
        //    objPaq.Central = pCentral;
        //    objPaq.Platillo = pPlatillo;
        //    dtable = objPaq.mgetConsultaPaquete();
        //    try
        //    {
        //        if (dtable.Rows.Count > 0)
        //        {

        //            for (int i = 1; i <= dtable.Rows.Count - 1; i++)
        //            {
        //                pPlatillo = int.Parse(dtable.Rows[0]["Platillo"].ToString());
        //                equivalencia = int.Parse(dtable.Rows[0]["Equivalencia"].ToString());

        //                if (equivalencia > 1)
        //                { validaEstadoPlatillo(2, pPlatillo); }
        //                else { validaEstadoPlatillo(3, pPlatillo); }

        //            }
        //        }
        //    }
        //    finally
        //    {
        //        validaEstadoPlatillo(estado, pPlatillo);
        //    }

        //}

        private void generaPlatilloTerminadores(int pPlatillo)
        {
            bool Terminador = false;
            DataTable dTerm = new DataTable();
            BOS_Platillo objPla = new BOS_Platillo();
            int estado = 0;

            try
            {
                objPla.Corporativo = pCorpo;
                objPla.Central = pCentral;
                objPla.Grupo = 0;
                objPla.Platillo = pPlatillo;
                dTerm = objPla.mgetConsultaPlatillosGrupo();
                if (dTerm.Rows.Count > 0)
                {
                    Terminador = bool.Parse(dTerm.Rows[0]["Terminador"].ToString());

                    if (Terminador == true)
                    {


                        DataTable dtable = new DataTable();
                        BOS_Terminador objTerm = new BOS_Terminador();
                        objTerm.Corporativo = pCorpo;
                        objTerm.Central = pCentral;
                        objTerm.Terminador = 0;
                        dtable = objTerm.mgetConsultaTerminador();

                        if (dtable.Rows.Count > 0)
                        {
                            pnlBtnTerminadores.Controls.Clear();

                            for (int i = 0; i <= dtable.Rows.Count - 1; i++)
                            {
                                Button btnTerminador = new Button();
                                btnTerminador.Text = dtable.Rows[i]["NombreTerminador"].ToString();


                                btnTerminador.Font.Bold = true;
                                btnTerminador.ID = "T" + dtable.Rows[i]["Terminador"].ToString() + "_" + pPlatillo;
                                //btnPla.ForeColor = System.Drawing.Color.White;
                                //btnPla.BackColor = System.Drawing.Color.LightSteelBlue;
                                btnTerminador.Font.Size = 8;
                                btnTerminador.Width = Unit.Pixel(210);
                                btnTerminador.Height = Unit.Pixel(40);
                                btnTerminador.CssClass = "btn btn-primary";
                                pnlBtnTerminadores.Controls.Add(btnTerminador);
                                pnlBtnTerminadores.Visible = true;
                                if (i % 2 != 0)
                                {
                                    pnlBtnTerminadores.Controls.Add(new LiteralControl("<div class=\"clearfix\"></div></br>"));
                                }
                                else { pnlBtnTerminadores.Controls.Add(new LiteralControl("&nbsp;&nbsp;&nbsp;")); }
                                btnTerminador.Click += new EventHandler(btnTerminador_Click);
                            }

                            Session["sTerminador"] = pPlatillo;

                        }

                    }
                    else
                    {
                        estado = 3;
                    }
                }
            }
            finally
            {
                if (estado == 0)
                    this.modalExtTerminadores.Show();

                if (estado > 0)
                    procesaPlatillo(3);
            }


        }

        void btnTerminador_Click(object sender, EventArgs e)
        {

            Button btn = sender as Button;
            int longitud = btn.ID.Length;
            int ip = btn.ID.IndexOf("_");
            int terminador = int.Parse(btn.ID.ToString().Substring(1, ip - 1));
            ip = ip + 1;
            longitud = longitud - ip;
            int pPlatillo = int.Parse(btn.ID.ToString().Substring(ip, longitud));
            try
            {
                Session["Terminador"] = terminador;
                Session["TerminadorNombre"] = btn.Text;
            }
            finally
            {
                this.modalExtTerminadores.Hide();
                procesaPlatillo(3);
            }

        }

        private void generaPlatilloModificadores(int pPlatillo, int pGrupo, string pClasificacion)
        {
            bool Modificador = false;
            DataTable dMod = new DataTable();
            BOS_Platillo objPla = new BOS_Platillo();
            int estado = 0;

            try
            {
                objPla.Corporativo = pCorpo;
                objPla.Central = pCentral;
                objPla.Grupo = 0;
                objPla.Platillo = pPlatillo;
                dMod = objPla.mgetConsultaPlatillosGrupo();
                if (dMod.Rows.Count > 0)
                {
                    Modificador = bool.Parse(dMod.Rows[0]["Modificador"].ToString());

                    if (Modificador == true)
                    {

                        DataTable dtable = new DataTable();
                        BOS_Modificador objMod = new BOS_Modificador();

                        objMod.Corporativo = pCorpo;
                        objMod.Central = pCentral;
                        objMod.Grupo = pGrupo;
                        objMod.Clasificacion = pClasificacion;
                        dtable = objMod.mgetConsultaModificador();

                        if (dtable.Rows.Count > 0)
                        {
                            pnlBtnModificadores.Controls.Clear();

                            for (int i = 0; i <= dtable.Rows.Count - 1; i++)
                            {
                                Button btnModificador = new Button();
                                btnModificador.Text = dtable.Rows[i]["NombreModificador"].ToString();
                                btnModificador.Font.Bold = true;
                                btnModificador.ID = "M" + dtable.Rows[i]["Modificador"].ToString() + "_" + pPlatillo;
                                //btnPla.ForeColor = System.Drawing.Color.White;
                                //btnPla.BackColor = System.Drawing.Color.LightSteelBlue;
                                btnModificador.Font.Size = 8;
                                btnModificador.Width = Unit.Pixel(210);
                                btnModificador.Height = Unit.Pixel(40);
                                btnModificador.CssClass = "btn btn-primary";
                                pnlBtnModificadores.Controls.Add(btnModificador);
                                pnlBtnModificadores.Visible = true;
                                if (i % 2 != 0)
                                {
                                    pnlBtnModificadores.Controls.Add(new LiteralControl("<div class=\"clearfix\"></div></br>"));
                                }
                                else { pnlBtnModificadores.Controls.Add(new LiteralControl("&nbsp;&nbsp;&nbsp;")); }
                                btnModificador.Click += new EventHandler(btnModificador_Click);
                            }
                            Session["sModificador"] = pPlatillo;
                            Session["sModGrupo"] = pGrupo;
                            Session["sModCla"] = pClasificacion;
                        }
                    }
                    else
                    {
                        estado = 4;

                    }

                }

            }
            finally
            {
                if (estado == 0)
                    this.modalExtModificadores.Show();

                if (estado > 0)
                    procesaPlatillo(4);

            }




        }

        void btnModificador_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            int longitud = btn.ID.Length;
            int ip = btn.ID.IndexOf("_");
            int modificador = int.Parse(btn.ID.ToString().Substring(1, ip - 1));
            ip = ip + 1;
            longitud = longitud - ip;
            int pPlatillo = int.Parse(btn.ID.ToString().Substring(ip, longitud));

            try
            {
                Session["Modificador"] = modificador;
                Session["ModificadorNombre"] = btn.Text;

            }
            finally
            {
                modalExtModificadores.Hide();
                procesaPlatillo(4);
            }

        }

        private void generaPlatilloPromociones()
        {
            int estado = 0;
            int pPlatillo = 0;
            DataTable dMod = new DataTable();
            BOS_Platillo objPla = new BOS_Platillo();

            try
            {
                List<BOS_PlatilloOrden> lista = new List<BOS_PlatilloOrden>();

                if (HttpContext.Current.Session["listaPlatillos"] != null)
                {
                    lista = (List<BOS_PlatilloOrden>)HttpContext.Current.Session["listaPlatillos"];
                    var plista = lista.Where(x => x.Promocion == true && x.Procesado == false).FirstOrDefault();

                    if (plista != null)
                    {

                        pPlatillo = plista.Platillo;
                        Session["sPlatilloPromocion"] = pPlatillo;


                        DataTable dtable = new DataTable();
                        BOS_Promocion objPro = new BOS_Promocion();

                        objPro.Corporativo = pCorpo;
                        objPro.Central = pCentral;
                        objPro.Platillo = pPlatillo;
                        objPro.Fecha_Proceso = DateTime.Now.ToString("yyyy-MM-dd");
                        dtable = objPro.mgetConsultaPromocion();

                        if (dtable.Rows.Count > 0)
                        {
                            // genera lista de las promociones
                            for (int i = 0; i < dtable.Rows.Count ; i++)
                            {
                                BOS_Reemplaza reemplazoNuevo = new BOS_Reemplaza();
                                reemplazoNuevo.Platillo = pPlatillo;
                                reemplazoNuevo.PlatilloPromocion = int.Parse(dtable.Rows[i]["PlatilloPromocion"].ToString());
                                reemplazoNuevo.NombrePlatillo = dtable.Rows[i]["NombrePlatillo"].ToString();
                                reemplazoNuevo.Cantidad = int.Parse(dtable.Rows[i]["Cantidad"].ToString());
                                reemplazoNuevo.Importe = decimal.Parse(dtable.Rows[i]["Importe"].ToString());
                                reemplazoNuevo.Reemplaza = bool.Parse(dtable.Rows[i]["Reemplaza"].ToString());
                                reemplazoNuevo.NoPregunta = bool.Parse(dtable.Rows[i]["Pregunta"].ToString());
                                reemplazoNuevo.Clasificacion = dtable.Rows[i]["Clasificacion"].ToString();                                
                                reemplazoNuevo.Proceso = false;
                                reemplazoNuevo.Linea_Paquete = pPlatillo;
                                listaReemplazo.Add(reemplazoNuevo);
                            }

                            estado = 1;
                           

                        }

                    }

                }

            }
            finally
            {
                if (estado == 0)
                    HttpContext.Current.Session["listaPlatillos"] = null;

                if (estado > 0)
                    generaReemplazos();

            }
        }


        private void generaReemplazos()
        {
            bool Reemplaza = false;
            bool NoPregunta = false;
            int estado = 0;

            try
            {
                List<BOS_Reemplaza> lista = new List<BOS_Reemplaza>();
                if (HttpContext.Current.Session["listaReemplazo"] != null)
                {
                    lista = (List<BOS_Reemplaza>)HttpContext.Current.Session["listaReemplazo"];
                    var plista = lista.Where(x => x.Proceso == false).FirstOrDefault();

                    if (plista != null)
                    {
                        //aqui ta debe traer la lsta de promociones 
                        Reemplaza = plista.Reemplaza;
                        NoPregunta = plista.NoPregunta;

                        Session["sPrecioPromocion"] = plista.Importe;
                        Session["sCantidadPromocion"] = plista.Cantidad;


                        if (Reemplaza == false && NoPregunta == true)//reemplazar sin preguntar
                        {
                            reemplazaSinPreguntar(plista.PlatilloPromocion, plista.Importe, true, plista.Linea_Paquete);
                            plista.Proceso = true;                           
                            estado = 2;
                        }
                        else if (Reemplaza == false && NoPregunta == false)// no reemplaza y pregunta
                        {
                            lblPregunta.Text = "¿DESEA " + plista.NombrePlatillo + " POR " + plista.Importe.ToString("C2") + " MAS?";
                            HttpContext.Current.Session["sPlatilloReemplazo"] = plista.PlatilloPromocion;
                            HttpContext.Current.Session["sReemplazos"] = plista.Platillo;
                            HttpContext.Current.Session["sPromoPreguntando"] = true;
                            estado = 1;
                        }
                        else if (Reemplaza == true && NoPregunta == false) //reemplaza y pregunta
                        {

                            lblPregunta.Text = "¿DESEA " + plista.NombrePlatillo + " POR " + plista.Importe.ToString("C2") + " MAS?";
                            HttpContext.Current.Session["sPlatilloReemplazo"] = plista.PlatilloPromocion;
                            HttpContext.Current.Session["sReemplazos"] = plista.Platillo;
                            HttpContext.Current.Session["sReemplazoClasificacion"] = plista.Clasificacion;
                            estado = 1;
                        }
                    }
                    else
                    {
                        List<BOS_PlatilloOrden> listaP = new List<BOS_PlatilloOrden>();
                        if (HttpContext.Current.Session["listaPlatillos"] != null)
                        {
                            listaP = (List<BOS_PlatilloOrden>)HttpContext.Current.Session["listaPlatillos"];
                            var plistaP = listaP.Where(x => x.Platillo == int.Parse(HttpContext.Current.Session["sPlatilloPromocion"].ToString())).FirstOrDefault();
                            plistaP.Procesado = true;

                        }

                        HttpContext.Current.Session["sPlatilloPromocion"] = null;
                        HttpContext.Current.Session["sReemplazos"] = null;
                        HttpContext.Current.Session["listaReemplazo"] = null;

                        if (HttpContext.Current.Session["sPromoPreguntando"] != null)
                        {
                            procesaPlatillo(1);
                            refreshGrdOrdenPromo();

                        }

                        modalExtPreguntaPromo.Hide();

                    }

                }
            }
            finally
            {
                if (estado == 0)
                    generaPlatilloPromociones();

                if (estado == 1)
                    this.modalExtPreguntaPromo.Show();

                if (estado == 2)
                    procesaPlatillo(1);



            }


        }

        void btnPromocion_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            int longitud = btn.ID.Length;
            int ip = btn.ID.IndexOf("_");
            int linea = int.Parse(btn.ID.ToString().Substring(1, ip - 1));
            ip = ip + 1;
            longitud = longitud - ip;
            int pPlatillo = int.Parse(btn.ID.ToString().Substring(ip, longitud));

            int pPlatilloFinal = 0;
            int pPlatilloFinalCantidad = 0;
            decimal pPlatilloFinalPrecio = 0;
            string pPlatilloNombre = "";

            try
            {
                //actualiza el estatus del platillo de la lista de promociones 
                List<BOS_Reemplaza> listaR = new List<BOS_Reemplaza>();
                if (HttpContext.Current.Session["listaReemplazo"] != null)
                {
                    listaR = (List<BOS_Reemplaza>)HttpContext.Current.Session["listaReemplazo"];
                    var plistaR = listaR.Where(z => z.Proceso == false).FirstOrDefault();
                    plistaR.Proceso = true;

                    // se obtiene el platillo que va a reemplazar al original 
                    pPlatilloFinal = plistaR.PlatilloPromocion;
                    pPlatilloFinalPrecio = plistaR.Importe;
                    pPlatilloFinalCantidad = plistaR.Cantidad;
                    pPlatilloNombre = plistaR.NombrePlatillo;

                }


                // aqui debe borrar de la lista y agregar el platillo seleccionado
                //generaReemplazos();
                var listPlatillosAReemplazar = listaOrdenDetalle.FirstOrDefault(x => x.Linea_Paquete == int.Parse(HttpContext.Current.Session["sLineaPaquete"].ToString()) && x.Platillo == pPlatillo && x.Linea == linea);
                if (listPlatillosAReemplazar != null)
                {
                    listPlatillosAReemplazar.Platillo = pPlatilloFinal;
                    listPlatillosAReemplazar.Nombre_Platillo = pPlatilloNombre;
                    listPlatillosAReemplazar.Precio = pPlatilloFinalPrecio;
                    listPlatillosAReemplazar.Precio_Neto = pPlatilloFinalPrecio;
                    listPlatillosAReemplazar.Cantidad = pPlatilloFinalCantidad;
                    sumaTotales(listPlatillosAReemplazar.Precio);
                }



            }
            finally
            {
                //Se selecciona el platillo que se va a reemplazar
                Session["sPlatilloReemplazo"] = pPlatillo;
                modalExtPromociones.Hide();
                generaReemplazos();
                refreshGrdOrdenPromo();

            }

        }

        protected void btnPromoSi_Click(object sender, EventArgs e)
        {
            int pPlatilloFinal = 0;

            try
            {

                if (HttpContext.Current.Session["sPromoPreguntando"] != null)
                {
                    List<BOS_Reemplaza> listaR = new List<BOS_Reemplaza>();
                    if (HttpContext.Current.Session["listaReemplazo"] != null)
                    {
                        listaR = (List<BOS_Reemplaza>)HttpContext.Current.Session["listaReemplazo"];
                        var plistaR = listaR.Where(z => z.Proceso == false).FirstOrDefault();
                        plistaR.Proceso = true;

                        reemplazaSinPreguntar(plistaR.PlatilloPromocion, plistaR.Importe, false, plistaR.Linea_Paquete);
                    }



                }
                else
                {

                    generaPromociones();
                }



            }
            finally
            {
                if (HttpContext.Current.Session["sPromoPreguntando"] != null)
                {
                    this.modalExtPreguntaPromo.Hide();
                    procesaPlatillo(2);
                    generaReemplazos();


                }
                else
                {

                    Session["sProcesaPromocion"] = true;
                    this.modalExtPreguntaPromo.Hide();
                    this.modalExtPromociones.Show();
                }

            }




        }


        protected void btnPromoNo_Click(object sender, EventArgs e)
        {

            List<BOS_Reemplaza> listaR = new List<BOS_Reemplaza>();
            if (HttpContext.Current.Session["listaReemplazo"] != null)
            {
                listaR = (List<BOS_Reemplaza>)HttpContext.Current.Session["listaReemplazo"];
                var plistaR = listaR.Where(z => z.Proceso == false).FirstOrDefault();
                plistaR.Proceso = true;
            }

            Session["sProcesaPromocion"] = null;
            this.modalExtPromociones.Hide();
            generaReemplazos();
            refreshGrdOrdenPromo();

        }


        private void generaPromociones()
        {
            int k = 0;
            int i = 0;
            var listPlatillosAReemplazar = listaOrdenDetalle.Where(x => x.Linea_Paquete == int.Parse(HttpContext.Current.Session["sLineaPaquete"].ToString()) && x.Clasificacion == HttpContext.Current.Session["sReemplazoClasificacion"].ToString() );

            if (listPlatillosAReemplazar.Count() > 0)
            {
                pnlBtnPromociones.Controls.Clear();

                foreach (var item in listPlatillosAReemplazar)
                {
                    if (item.Platillo != int.Parse(HttpContext.Current.Session["sPlatilloPromocion"].ToString()))
                    {
                        Button btnPromocion = new Button();
                        btnPromocion.Text = item.Nombre_Platillo;
                        btnPromocion.Font.Bold = true;
                        btnPromocion.ID = "P" + item.Linea.ToString() + "_" +item.Platillo.ToString();
                        //btnPla.ForeColor = System.Drawing.Color.White;
                        //btnPla.BackColor = System.Drawing.Color.LightSteelBlue;
                        btnPromocion.Font.Size = 8;
                        btnPromocion.Width = Unit.Pixel(210);
                        btnPromocion.Height = Unit.Pixel(40);
                        btnPromocion.CssClass = "btn btn-primary";
                        pnlBtnPromociones.Controls.Add(btnPromocion);
                        pnlBtnPromociones.Visible = true;
                        if (k % 2 != 0)
                        {
                            pnlBtnPromociones.Controls.Add(new LiteralControl("<div class=\"clearfix\"></div></br>"));
                        }
                        else { pnlBtnPromociones.Controls.Add(new LiteralControl("&nbsp;")); }
                        btnPromocion.Click += new EventHandler(btnPromocion_Click);

                    }

                    k++;
                }
            }

        }


        //******************************
        // ** Reemplza sin preguntar **
        //******************************
        private void reemplazaSinPreguntar(int pPlatilloPromocion, decimal pImporte, bool pNoPregunta, int pLineaPaquete)
        {
            try
            {
                int contador = 0;
                DataTable dtblPromo = new DataTable();
                BOS_Platillo objPla = new BOS_Platillo();
                objPla.Corporativo = pCorpo;
                objPla.Central = pCentral;
                objPla.Grupo = 0;
                objPla.Platillo = pPlatilloPromocion;
                dtblPromo = objPla.mgetConsultaPlatillosGrupo();

                if (dtblPromo.Rows.Count > 0)
                {
                    contador = int.Parse(HttpContext.Current.Session["sContadorProceso"].ToString());

                    //if (HttpContext.Current.Session["sPromoPreguntando"] != null)
                    //{
                    //    contador = 0;
                    //}

                    Session["sContadorProceso"] = contador;
                    BOS_PlatilloOrden platilloNuevo = new BOS_PlatilloOrden();
                    platilloNuevo.Id = contador;
                    platilloNuevo.Platillo = int.Parse(dtblPromo.Rows[0]["Platillo"].ToString());
                    platilloNuevo.Grupo = int.Parse(dtblPromo.Rows[0]["Grupo"].ToString());
                    platilloNuevo.Clasificacion = dtblPromo.Rows[0]["Clasificacion"].ToString();
                    platilloNuevo.Modificador = bool.Parse(dtblPromo.Rows[0]["Modificador"].ToString());
                    platilloNuevo.Modificador_Cantidad = int.Parse(dtblPromo.Rows[0]["ModificadorCantidad"].ToString());
                    platilloNuevo.Terminador = bool.Parse(dtblPromo.Rows[0]["Terminador"].ToString());
                    platilloNuevo.Precio = pImporte;
                    platilloNuevo.Paquete = false;
                    platilloNuevo.Promocion = false;
                    platilloNuevo.Equivalencia = 0;
                    platilloNuevo.NoPregunta = pNoPregunta;
                    platilloNuevo.Linea_Paquete = pLineaPaquete;
                    //platilloNuevo.Procesado = true;                              
                    listaPlatillos.Add(platilloNuevo);


                }
            }
            finally
            {               
                Session["sProcesaPromocion"] = true;
            }

        }


        //************************
        // ** Notas platillo **
        //************************
        protected void btnNotasPla_Click(object sender, EventArgs e)
        {
            if (txtNotasPla.Text != "")
            {
                int pLinea = int.Parse(HttpContext.Current.Session["sLineaEdit"].ToString());
                var linea = listaOrdenDetalle.Where(x => x.Linea == pLinea).FirstOrDefault();
                linea.Nota_Platillo = "N/" + txtNotasPla.Text;
                linea.NotVisible = true;
                refreshGrdOrden();
            }

            txtNotasPla.Text = "";
            this.modalExtNotasPla.Hide();

        }

        protected void btnNotasPlaCan_Click(object sender, EventArgs e)
        {
            txtNotasPla.Text = "";
            this.modalExtNotasPla.Hide();

        }


        //************************
        // ** Control Paneles **
        //************************
        private void cambiaPanel()
        {
            string panelactivo;
            panelactivo = Session["sPanelAct"].ToString();

            switch (panelactivo)
            {
                case "divGpo":
                    divGpo.Attributes["class"] = "tab-pane fade in active";
                    divPGrupo.Attributes["class"] = "tab-pane fade";
                    divPTurno.Attributes["class"] = "tab-pane fade";
                    divBusqueda.Attributes["class"] = "tab-pane fade";
                    break;

                case "divPGrupo":
                    divGpo.Attributes["class"] = "tab-pane fade";
                    divPGrupo.Attributes["class"] = "tab-pane fade in active";
                    divPTurno.Attributes["class"] = "tab-pane fade";
                    divBusqueda.Attributes["class"] = "tab-pane fade";
                    break;

                case "divPTurno":
                    divGpo.Attributes["class"] = "tab-pane fade";
                    divPGrupo.Attributes["class"] = "tab-pane fade";
                    divPTurno.Attributes["class"] = "tab-pane fade in active";
                    divBusqueda.Attributes["class"] = "tab-pane fade";
                    break;

                case "divBusqueda":
                    divGpo.Attributes["class"] = "tab-pane fade";
                    divPGrupo.Attributes["class"] = "tab-pane fade";
                    divPTurno.Attributes["class"] = "tab-pane fade";
                    divBusqueda.Attributes["class"] = "tab-pane fade in active";
                    break;


                default:
                    divGpo.Attributes["class"] = "tab-pane fade in active";
                    divPGrupo.Attributes["class"] = "tab-pane fade";
                    divPTurno.Attributes["class"] = "tab-pane fade";
                    divBusqueda.Attributes["class"] = "tab-pane fade";
                    break;
            }


        }

        private void showMessage(string msgA, string msgB, string St_Mensaje)
        {
            St_Mensaje = St_Mensaje + "\n" + msgA + "\n" + msgB;
            lblModalTitleError.Text = "Bluekey Order System";
            lblModalBodyError.Text = St_Mensaje;
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "myModal", "$('#myModalError').modal();", true);
            upModalError.Update();

        }


        //*************************************************
        //******  Procesa platillo  **********
        //*************************************************
        private void procesaPlatillo(int pEstado)
        {


            int pla = 0;
            int contador = 0;
            List<BOS_PlatilloOrden> lista = new List<BOS_PlatilloOrden>();
            

            if (HttpContext.Current.Session["listaPlatillos"] != null)
            {
                if (HttpContext.Current.Session["sContadorProceso"] != null)
                {
                    contador = int.Parse(HttpContext.Current.Session["sContadorProceso"].ToString());
                }
                else
                {
                    contador = 0;
                }


                lista = (List<BOS_PlatilloOrden>)HttpContext.Current.Session["listaPlatillos"];
                var plista = lista.Where(x => x.Id == contador).FirstOrDefault();

                pla = lista.Count();

                if (contador < pla)
                {

                    switch (pEstado)
                    {
                        // equivalencias
                        case 1:
                            generaPlatilloEquivalencia(plista.Platillo);
                            break;

                        //terminadores
                        case 2:
                            generaPlatilloTerminadores(plista.Platillo);
                            break;

                        //modificadores 
                        case 3:
                            generaPlatilloModificadores(plista.Platillo, plista.Grupo, plista.Clasificacion);
                            break;

                        //agrega orden
                        case 4:
                            contador++;
                            Session["sContadorProceso"] = contador;
                            agregaOrdenDetalle(plista.Platillo, plista.Linea_Paquete, plista.NoPregunta);
                            refreshGrdOrden();
                            break;

                        default:
                            break;

                    }
                }
                else
                {
                    HttpContext.Current.Session["sEquivalencia"] = null;
                    HttpContext.Current.Session["sTerminador"] = null;
                    HttpContext.Current.Session["sModificador"] = null;
                    HttpContext.Current.Session["sModGrupo"] = null;
                    HttpContext.Current.Session["sModCla"] = null;
                    //HttpContext.Current.Session["sLineaPaquete"] = null;

                    if (HttpContext.Current.Session["sProcesaPromocion"] == null)
                    {
                        generaPlatilloPromociones();

                        if (HttpContext.Current.Session["listaReemplazo"] != null)
                        {
                            generaReemplazos();
                        }

                    }
                    else
                    {
                        if (HttpContext.Current.Session["listaReemplazo"] != null)
                        {
                            generaReemplazos();
                        }

                        if (HttpContext.Current.Session["sPromoPreguntando"] == null)
                            HttpContext.Current.Session["listaPlatillos"] = null;

                        HttpContext.Current.Session["sPrecioPromocion"] = null;
                        HttpContext.Current.Session["sCantidadPromocion"] = null;
                    }


                }

            }
        }


        //**************************
        // ** Control Comensales **
        //**************************
        protected void btnDowTot_Click(object sender, ImageClickEventArgs e)
        {
            int comTot = 0;
            if (int.TryParse(txtTotCom.Text, out comTot))
            {
                comTot--;
                if (comTot <= 0)
                    comTot = 1;
                txtTotCom.Text = comTot.ToString();
            }
        }

        protected void btnUpTot_Click(object sender, ImageClickEventArgs e)
        {
            int comTot = 0;
            if (int.TryParse(txtTotCom.Text, out comTot))
            {
                comTot++;
                txtTotCom.Text = comTot.ToString();
            }
            else
            {
                comTot = 1;
                txtTotCom.Text = comTot.ToString();
            }
        }

        protected void btnDow_Click(object sender, ImageClickEventArgs e)
        {
            int comTot = 0;
            if (int.TryParse(txtCom.Text, out comTot))
            {
                comTot--;
                if (comTot <= 0)
                    comTot = 1;
                txtCom.Text = comTot.ToString();
            }
        }

        protected void btnUp_Click(object sender, ImageClickEventArgs e)
        {
            int comTot = 0;
            if (int.TryParse(txtCom.Text, out comTot))
            {
                comTot++;

                if (comTot > int.Parse(txtTotCom.Text))
                    comTot = int.Parse(txtTotCom.Text);

                txtCom.Text = comTot.ToString();
            }
            else
            {
                comTot = 1;
                txtCom.Text = comTot.ToString();
            }
        }

        //**************************
        // ** Funciones Grid  **
        //**************************
        protected void grdCaptura_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int pLinea = 0;
            decimal pPrecio = 0;
            decimal iva = (decimal)1 + (decimal).16;


            if (e.CommandName.Equals("cmdLess"))
            {
                decimal precioPaq = 0;
                decimal precioProm = 0;

                pLinea = int.Parse(e.CommandArgument.ToString());
                var linea = listaOrdenDetalle.Where(x => x.Linea == pLinea).FirstOrDefault();
                if (linea.Cantidad > 1)
                {
                    var paquete = listaOrdenDetalle.Where(x => x.Linea_Paquete == pLinea).Count();
                    var promocion = listaOrdenDetalle.Where(x => x.Linea_Promocion == pLinea).Count();

                    if (paquete > 0)
                    {
                        var plaPaq = listaOrdenDetalle.Where(x => x.Linea_Paquete == pLinea).ToList();
                        foreach (var item in plaPaq)
                        {
                            item.Cantidad = item.Cantidad - 1;
                            precioPaq = precioPaq - item.Precio;
                        }
                        linea.Precio_Neto = decimal.Round(((precioPaq / iva) * (decimal)linea.Cantidad), 4);
                        restaTotales(pPrecio);
                    }
                    else if (promocion > 0)
                    {
                        var plaProm = listaOrdenDetalle.Where(x => x.Linea_Promocion == pLinea).ToList();
                        foreach (var item in plaProm)
                        {
                            item.Cantidad = item.Cantidad - 1;
                            if (precioProm == 0)
                            {
                                precioProm = item.Precio;
                            }
                            else
                            {
                                precioProm = precioProm - item.Precio;
                            }

                        }
                        linea.Precio_Neto = decimal.Round(((precioProm / iva) * (decimal)linea.Cantidad), 4);
                        restaTotales(precioProm);
                    }
                    else
                    {

                        linea.Cantidad = linea.Cantidad - 1;
                        pPrecio = linea.Precio;
                        linea.Precio_Neto = decimal.Round(((pPrecio / iva) * (decimal)linea.Cantidad), 4);
                        restaTotales(pPrecio);
                    }

                    refreshGrdOrden();
                }

            }
            else if (e.CommandName.Equals("cmdMore"))
            {
                int pPlatillo = 0;

                decimal precioPaq = 0;
                decimal precioProm = 0;
                pLinea = int.Parse(e.CommandArgument.ToString());
                var linea = listaOrdenDetalle.Where(x => x.Linea == pLinea).FirstOrDefault();
                pPlatillo = linea.Platillo;

                var paquete = listaOrdenDetalle.Where(x => x.Linea_Paquete == pLinea).Count();
                var promocion = listaOrdenDetalle.Where(x => x.Linea_Promocion == pLinea).Count();
                var noPregunta = listaOrdenDetalle.Where(x => x.NoPregunta == true && x.Linea_Promocion == pLinea).Count();

                if (paquete > 0)
                {
                    //var plaPaq = listaOrdenDetalle.Where(x => x.Linea_Paquete == pLinea).ToList();
                    //foreach (var item in plaPaq)
                    //{
                    //    item.Cantidad = item.Cantidad + 1;
                    //    precioPaq = precioPaq + item.Precio;
                    //}
                    generaPlatillo(pPlatillo);
                    refreshGrdOrdenPromo();
                    //sumaTotales(precioPaq);
                }
                else if (promocion > 0 && noPregunta > 0)
                {
                    var plaProm = listaOrdenDetalle.Where(x => x.Linea_Promocion == pLinea).ToList();
                    foreach (var item in plaProm)
                    {
                        item.Cantidad = item.Cantidad + 1;
                        precioProm = precioProm + item.Precio;
                    }
                    linea.Precio_Neto = decimal.Round(((precioProm / iva) * (decimal)linea.Cantidad), 4);
                    sumaTotales(precioProm);
                    refreshGrdOrden();


                }
                else if (promocion > 0 && noPregunta == 0)
                {
                    generaPlatillo(pPlatillo);
                    refreshGrdOrdenPromo();
                }
                else
                {
                    linea.Cantidad = linea.Cantidad + 1;
                    pPrecio = linea.Precio;
                    linea.Precio_Neto = decimal.Round(((pPrecio / iva) * (decimal)linea.Cantidad), 4);
                    sumaTotales(pPrecio);
                    refreshGrdOrden();

                }



            }
            else if (e.CommandName.Equals("cmdDel"))
            {
                pLinea = int.Parse(e.CommandArgument.ToString());
                var linea = listaOrdenDetalle.Where(x => x.Linea == pLinea).FirstOrDefault();
                pPrecio = linea.Precio;
                listaOrdenDetalle.Remove(linea);
                restaTotales(pPrecio);

                var paquete = listaOrdenDetalle.Where(x => x.Linea_Paquete == pLinea).Count();
                var precioPaquete = listaOrdenDetalle.Where(x => x.Linea_Paquete == pLinea).Sum(x => x.Precio);
                var promocion = listaOrdenDetalle.Where(x => x.Linea_Promocion == pLinea).Count();
                var precioPromo = listaOrdenDetalle.Where(x => x.Linea_Promocion == pLinea).Sum(x => x.Precio);

                if (paquete > 0)
                {
                    listaOrdenDetalle.RemoveAll(x => x.Linea_Paquete == pLinea);
                    restaTotales(precioPaquete);
                }
                else if (promocion > 0)
                {
                    listaOrdenDetalle.RemoveAll(x => x.Linea_Promocion == pLinea);
                    restaTotales(precioPromo);
                }

                refreshGrdOrdenPromo();

            }
            else if (e.CommandName.Equals("cmdEdit"))
            {

                pLinea = int.Parse(e.CommandArgument.ToString());
                var linea = listaOrdenDetalle.Where(x => x.Linea == pLinea).FirstOrDefault();
                lblNotasPla.Text = linea.Nombre_Platillo;
                Session["sLineaEdit"] = linea.Linea;

                if (linea.Nota_Platillo != "")
                    txtNotasPla.Text = linea.Nota_Platillo.Substring(2);

                modalExtNotasPla.Show();

            }
            else if (e.CommandName.Equals("cmdUpCom"))
            {
                pLinea = int.Parse(e.CommandArgument.ToString());
                var linea = listaOrdenDetalle.Where(x => x.Linea == pLinea).FirstOrDefault();

                int comTot = linea.Comensal;
               
                comTot++;

                if (comTot > int.Parse(txtTotCom.Text))
                    comTot = int.Parse(txtTotCom.Text);

                var paquete = listaOrdenDetalle.Where(x => x.Linea_Paquete == pLinea).Count();
                var promocion = listaOrdenDetalle.Where(x => x.Linea_Promocion == pLinea).Count();

                if (paquete > 0)
                {
                    var plaPaq = listaOrdenDetalle.Where(x => x.Linea_Paquete == pLinea).ToList();
                    foreach (var item in plaPaq)
                    {
                        var lineaPaquete = listaOrdenDetalle.Where(x => x.Linea == item.Linea).FirstOrDefault();
                        lineaPaquete.Comensal = comTot;
                    }


                }

                if ( paquete > 0  || promocion>0 )
                {
                    var plaProm = listaOrdenDetalle.Where(x => x.Linea_Promocion == pLinea).ToList();
                    foreach (var item in plaProm)
                    {
                        var lineaPaquete = listaOrdenDetalle.Where(x => x.Linea == item.Linea).FirstOrDefault();
                        lineaPaquete.Comensal = comTot;
                    }                  


                }

                linea.Comensal = comTot;
                refreshGrdOrdenPromo();

            }
            else if (e.CommandName.Equals("cmdDownCom"))
            {
                pLinea = int.Parse(e.CommandArgument.ToString());
                var linea = listaOrdenDetalle.Where(x => x.Linea == pLinea).FirstOrDefault();

                int comTot = linea.Comensal;
               
                comTot--;

                if (comTot <= 0)
                    comTot = 1;

                var paquete = listaOrdenDetalle.Where(x => x.Linea_Paquete == pLinea).Count();
                var promocion = listaOrdenDetalle.Where(x => x.Linea_Promocion == pLinea).Count();

                if (paquete > 0)
                {
                    var plaPaq = listaOrdenDetalle.Where(x => x.Linea_Paquete == pLinea).ToList();
                    foreach (var item in plaPaq)
                    {
                        var lineaPaquete = listaOrdenDetalle.Where(x => x.Linea == item.Linea).FirstOrDefault();
                        lineaPaquete.Comensal = comTot;
                    }


                }

                if (paquete > 0 || promocion > 0)
                {
                    var plaProm = listaOrdenDetalle.Where(x => x.Linea_Promocion == pLinea).ToList();
                    foreach (var item in plaProm)
                    {
                        var lineaPaquete = listaOrdenDetalle.Where(x => x.Linea == item.Linea).FirstOrDefault();
                        lineaPaquete.Comensal = comTot;
                    }


                }


                linea.Comensal= comTot; 
                refreshGrdOrdenPromo();

            }




        }


        //**************************
        // ** Ordenes a Futuro **
        //**************************

        protected void cbxFuturo_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxFuturo.Checked)
            {
                modalExtFuturo.Show();
            }

        }


        private void iniciaVariablesPlatillo()
        {
            Session["sLineaPaquete"] = null;
            Session["listaPlatillos"] = null;
            Session["listaReemplazo"] = null;
            Session["sLineaPromocion"] = null;
            Session["sPromoPreguntando"] = null;
            Session["sProcesaPromocion"] = null;

        }


        protected void btnGrdFut_Click(object sender, EventArgs e)
        {
            Session["sFechaPromesa"] = null;
            switch (validaHorariosOrdenFuturo())
            {

                case 0: //la hora no puede ser menor a la minima
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Bluekey Message", "alert('La hora capturada deber ser mayor!')", true);
                    modalExtFuturo.Show();
                    break;
                case 1: //la hora no puede ser mayor a la maxima
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Bluekey Message", "alert('La hora capturada deber ser menor!')", true);
                    modalExtFuturo.Show();
                    break;
                case 2: // se guarda la fecha y hora capturada por el usuario
                    Session["sFechaPromesa"] = txtFec.Text + " " + txtHora.Text + ":" + txtMinutos.Text;
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Bluekey Message", "alert('Fecha y hora valida!')", true);
                    modalExtFuturo.Hide();
                    break;             
               

            }

           

        }

       

        protected void btnCanFut_Click(object sender, EventArgs e)
        {

            cbxFuturo.Checked = false;
            txtFec.Text = "";
            txtHora.Text = "";
            txtMinutos.Text = "";
            Session["sFechaPromesa"] = null;
            modalExtFuturo.Hide();


        }

        private int validaHorariosOrdenFuturo()
        {
            int proceso ;

            DataTable dtable = new DataTable();
            BOS_Central objOF = new BOS_Central();
            objOF.Corporativo = pCorpo;
            objOF.Central = pCentral;
            dtable = objOF.mgetConsultaCentral();
            if (dtable.Rows.Count > 0)
            {
                pHoraIOF = dtable.Rows[0]["HoraInicial"].ToString();
                pHoraFOF = dtable.Rows[0]["HoraFinal"].ToString();
                pMinOF = int.Parse(dtable.Rows[0]["MinutosOrdenFuturo"].ToString());
            }
            proceso = 0;

            string horaCapturada = txtHora.Text + ":" + txtMinutos.Text;
            int result = DateTime.Compare(DateTime.Parse(txtFec.Text), DateTime.Today);

            if (result > 0) // fecha mayor a la del dia
            {
                //comparar si la hora esta en el rango de horarios de la sucursal
                //no puede ser menor  a la hora inicial y ni mayor a la hora final               
                DateTime horaCapturadaValida = DateTime.Parse(horaCapturada);
                
                if (horaCapturadaValida < DateTime.Parse(pHoraIOF)  )
                {
                    proceso = 0;
                }
                else if (horaCapturadaValida > DateTime.Parse(pHoraFOF)  )
                {
                    proceso = 1;

                }
                else
                {
                    proceso = 2;
                }
              
                    
            }
            else if (result == 0) //la fecha del dia
            {
                //la hora minima no puede ser menor a la actual mas el numero de minutos 
                //del campo  minutosordenfuturo
                DateTime horaminima = pHoraInicio.AddMinutes(pMinOF);
                DateTime horaCapturadaValida = DateTime.Parse(horaCapturada);

                if (horaCapturadaValida < horaminima)
                {
                    proceso = 0;
                }
                else if (horaCapturadaValida > DateTime.Parse(pHoraFOF))
                {
                    proceso = 1;

                }
                else
                {
                    proceso = 2;
                }
            }

           
            return proceso;
        }


        protected void ddlFP_SelectedIndexChanged(object sender, EventArgs e)
        {
            pFormaPago = ddlFP.SelectedItem.Value.ToString();
            Session["sFormaPago"] = pFormaPago;
            actualizaOrden();

        }

        //**************************
        // ** Notas Orden **
        //**************************
        protected void BtnNota_Click(object sender, EventArgs e)
        {
            //notas de la orden
            var orden = listaOrden.FirstOrDefault();

            if ( orden.Nota != "")
                txtNotasOrden.Text = orden.Nota.Substring(2);
            
            modalExtNotasOrden.Show();
            

        }

        protected void btnNotasOrdenOk_Click(object sender, EventArgs e)
        {
            var orden = listaOrden.FirstOrDefault();
            orden.Nota = txtNotasOrden.Text;

            frmNotas= txtNotasOrden.Text;
            modalExtNotasOrden.Hide();
            
        }

        protected void btnNotasOrdenCan_Click(object sender, EventArgs e)
        {
            modalExtNotasOrden.Hide();
        }


        //private void validaEstadoPlatillo(int pEstado, int pPlatillo)
        //{
        //    switch (pEstado)
        //    {
        //        // equivalencias
        //        case 1:
        //            generaPlatilloEquivalencia(pPlatillo);
        //            break;

        //        //terminadores
        //        case 2:
        //            generaPlatilloTerminadores(pPlatillo);
        //            break;

        //        //modificadores 
        //        case 3:
        //            generaPlatilloModificadores(pPlatillo);
        //            break;

        //        //promociones
        //        case 4:
        //            generaPlatilloPromociones(pPlatillo);
        //            break;

        //        //agrega orden
        //        case 5:
        //            agregaOrdenDetalle(pPlatillo);
        //            refreshGrdOrden();                  
        //            break;

        //        default:
        //            break;

        //    }
        //}

    }
}