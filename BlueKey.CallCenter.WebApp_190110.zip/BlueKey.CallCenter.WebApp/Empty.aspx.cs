﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Bluekey.CallCenter.BusinessRule;

namespace BlueKey.CallCenter.WebApp
{
    public partial class Empty : System.Web.UI.Page
    {
        //lista de orden
        public List<BOS_Orden> listaOrden
        {
            get
            {
                if (HttpContext.Current.Session["listaOrden"] == null)
                {
                    HttpContext.Current.Session["listaOrden"] = new List<BOS_Orden>();
                }
                return HttpContext.Current.Session["listaOrden"] as List<BOS_Orden>;
            }
            set
            {
                HttpContext.Current.Session["listaOrden"] = value;
            }

        }


        //lista de platillos orden
        public List<BOS_OrdenDetalle> listaOrdenDetalle
        {
            get
            {
                if (HttpContext.Current.Session["listaOrdenDetalle"] == null)
                {
                    HttpContext.Current.Session["listaOrdenDetalle"] = new List<BOS_OrdenDetalle>();
                }
                return HttpContext.Current.Session["listaOrdenDetalle"] as List<BOS_OrdenDetalle>;
            }
            set
            {
                HttpContext.Current.Session["listaOrdenDetalle"] = value;
            }

        }

        //lista de platillos que se genera para procesar 
        public List<BOS_PlatilloOrden> listaPlatillos
        {
            get
            {
                if (HttpContext.Current.Session["listaPlatillos"] == null)
                {
                    HttpContext.Current.Session["listaPlatillos"] = new List<BOS_PlatilloOrden>();
                }
                return HttpContext.Current.Session["listaPlatillos"] as List<BOS_PlatilloOrden>;
            }

            set
            {
                HttpContext.Current.Session["listaPlatillos"] = value;
            }
        }


        protected void Page_Load(object sender, EventArgs e)
        {
            insertaOrden();
        }

        private void insertaOrden()
        {
            int numeroOrden =0;
            int numeroOrdenLinea = 0;
            var orden = listaOrden.FirstOrDefault();

            try
            {
                BOS_Orden objOrden = new BOS_Orden();
                objOrden.Corporativo = orden.Corporativo;
                objOrden.Central = orden.Central;
                objOrden.Sucursal = orden.Sucursal;
                objOrden.Id_Cliente = orden.Id_Cliente;
                objOrden.Id_Direccion = orden.Id_Direccion;
                objOrden.Comensales = orden.Comensales;
                objOrden.Turno = orden.Turno;
                objOrden.Nota = orden.Nota;
                objOrden.Origen = orden.Origen;
                objOrden.Forma_Pago = orden.Forma_Pago;
                objOrden.Fecha_Captura_Inicio = orden.Fecha_Captura_Inicio;
                objOrden.Operador_Captura = orden.Operador_Captura;
                objOrden.Fecha_Captura_Fin = orden.Fecha_Captura_Fin;
                objOrden.Fecha_Procesar = orden.Fecha_Procesar;
                objOrden.Promesa_Entrega = orden.Promesa_Entrega;
                objOrden.Estatus = "A";
                objOrden.Repartidor = orden.Repartidor;
                objOrden.Usuario_Cancela = orden.Usuario_Cancela;
                objOrden.Fecha_Cancela = orden.Fecha_Cancela;
                objOrden.Nota_Cancela = orden.Nota_Cancela;
                objOrden.RFC = orden.RFC;
                objOrden.Codigo_Postal = orden.Codigo_Postal;

                numeroOrden = objOrden.insertaOrden();



                var lineasOrden = listaOrdenDetalle.ToList();

                BOS_OrdenDetalle objOrdenLinea = new BOS_OrdenDetalle();

                foreach (var linea in lineasOrden)
                {

                    objOrdenLinea.Corporativo = linea.Corporativo;
                    objOrdenLinea.Central = linea.Central;
                    objOrdenLinea.Orden = numeroOrden;
                    objOrdenLinea.Linea = linea.Linea;
                    objOrdenLinea.Platillo = linea.Platillo;
                    objOrdenLinea.Nombre_Platillo = linea.Nombre_Platillo;
                    objOrdenLinea.Linea_Paquete = linea.Linea_Paquete;
                    objOrdenLinea.Comensal = linea.Comensal;
                    objOrdenLinea.Cantidad = linea.Cantidad;
                    objOrdenLinea.Precio = linea.Precio;
                    objOrdenLinea.Nota_Platillo = linea.Nota_Platillo;
                    objOrdenLinea.Terminador = linea.Terminador;
                    objOrdenLinea.Precio_Neto = linea.Precio_Neto;
                    objOrdenLinea.Servicio = linea.Servicio;
                    objOrdenLinea.Descuento = linea.Descuento;
                    objOrdenLinea.Descuento_Porcentaje = linea.Descuento_Porcentaje;
                    objOrdenLinea.Fecha_Captura_Platillo = linea.Fecha_Captura_Platillo;
                    objOrdenLinea.Activo = linea.Activo;
                    objOrdenLinea.Usuario_Cancela = linea.Usuario_Cancela;
                    objOrdenLinea.Fecha_Cancela = linea.Fecha_Cancela;
                    objOrdenLinea.Nota_Cancela = linea.Nota_Cancela;

                    numeroOrdenLinea = objOrdenLinea.insertaOrdenDetalle();



                }

               
            }
            catch (Exception Ex)
            {

                String A = Ex.Message;
                String B = Ex.Source;
                showMessage(A, B, "Error al insertar Pedido");
            }
            finally
            {

                //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Bluekey Message", "alert('Se genero el pedido " + numeroOrden.ToString() + " !')", true);
                showMessage("Se genero el pedido " + numeroOrden.ToString() + " !");
                Session.Clear();
            }

            
        }



        private void showMessage(string msgA)
        {            
            lblModalTitle.Text = "Bluekey Order System";
            lblModalBody.Text = msgA;
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "myModal", "$('#myModal').modal();", true);
            upModal.Update();

        }

        private void showMessage(string msgA, string msgB, string title)
        {
            String St_Mensaje = "";
            St_Mensaje = title + " \n" + msgA + "\n" + msgB;
            lblModalTitle.Text = "Bluekey Order System";
            lblModalBody.Text = St_Mensaje;
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "myModal", "$('#myModal').modal();", true);
            upModal.Update();

        }



    }
}